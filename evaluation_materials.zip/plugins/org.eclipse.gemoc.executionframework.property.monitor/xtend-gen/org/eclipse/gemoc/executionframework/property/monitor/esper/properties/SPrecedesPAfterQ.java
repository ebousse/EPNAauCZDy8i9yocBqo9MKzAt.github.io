package org.eclipse.gemoc.executionframework.property.monitor.esper.properties;

import java.util.List;
import java.util.Map;
import org.eclipse.gemoc.executionframework.property.model.property.After;
import org.eclipse.gemoc.executionframework.property.model.property.Precedence;
import org.eclipse.gemoc.executionframework.property.monitor.esper.TruthValue;
import org.eclipse.gemoc.executionframework.property.monitor.esper.properties.AbstractTemporalProperty;
import org.eclipse.viatra.query.patternlanguage.emf.specification.SpecificationBuilder;
import org.eclipse.viatra.query.runtime.api.IQuerySpecification;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class SPrecedesPAfterQ extends AbstractTemporalProperty {
  private final IQuerySpecification<?> p;
  
  private final IQuerySpecification<?> q;
  
  private final IQuerySpecification<?> s;
  
  public SPrecedesPAfterQ(final SpecificationBuilder builder, final String name, final Precedence response, final After after) {
    super(builder, name);
    this.p = builder.getOrCreateSpecification(response.getPattern());
    this.q = builder.getOrCreateSpecification(after.getLowerBoundPattern());
    this.s = builder.getOrCreateSpecification(response.getOtherPattern());
    this.queries.put(this.p.getFullyQualifiedName(), this.p);
    this.queries.put(this.q.getFullyQualifiedName(), this.q);
    this.queries.put(this.s.getFullyQualifiedName(), this.s);
  }
  
  @Override
  protected String getStatementString() {
    final String pFqn = this.getFqn(this.p);
    final String qFqn = this.getFqn(this.q);
    final String sFqn = this.getFqn(this.s);
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("select * from ");
    String _name = this.getName();
    _builder.append(_name);
    _builder.newLineIfNotEmpty();
    _builder.append("match_recognize (");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("measures P as P");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("pattern (EoE | Q A*? (EoE | S | P))");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("define");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("P as P.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("Q as Q.");
    _builder.append(qFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("S as S.");
    _builder.append(sFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("EoE as EoE.executionAboutToStop? is not null");
    _builder.newLine();
    _builder.append(")");
    _builder.newLine();
    final String result = _builder.toString();
    return result;
  }
  
  @Override
  protected TruthValue getStatus(final Map<String, List<Map<?, ?>>> events) {
    final List<Map<?, ?>> lP = events.get("P");
    final boolean reachedP = (!((lP == null) || lP.isEmpty()));
    if (reachedP) {
      return TruthValue.VIOLATED;
    } else {
      return TruthValue.SATISFIED;
    }
  }
}
