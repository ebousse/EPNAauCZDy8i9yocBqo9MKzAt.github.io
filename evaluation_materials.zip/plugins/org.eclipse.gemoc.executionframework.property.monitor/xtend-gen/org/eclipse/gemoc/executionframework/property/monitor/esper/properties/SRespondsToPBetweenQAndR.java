package org.eclipse.gemoc.executionframework.property.monitor.esper.properties;

import java.util.List;
import java.util.Map;
import org.eclipse.gemoc.executionframework.property.model.property.Between;
import org.eclipse.gemoc.executionframework.property.model.property.Response;
import org.eclipse.gemoc.executionframework.property.monitor.esper.TruthValue;
import org.eclipse.gemoc.executionframework.property.monitor.esper.properties.AbstractTemporalProperty;
import org.eclipse.viatra.query.patternlanguage.emf.specification.SpecificationBuilder;
import org.eclipse.viatra.query.runtime.api.IQuerySpecification;
import org.eclipse.xtend2.lib.StringConcatenation;

@SuppressWarnings("all")
public class SRespondsToPBetweenQAndR extends AbstractTemporalProperty {
  private final IQuerySpecification<?> p;
  
  private final IQuerySpecification<?> q;
  
  private final IQuerySpecification<?> r;
  
  private final IQuerySpecification<?> s;
  
  public SRespondsToPBetweenQAndR(final SpecificationBuilder builder, final String name, final Response response, final Between between) {
    super(builder, name);
    this.p = builder.getOrCreateSpecification(response.getPattern());
    this.q = builder.getOrCreateSpecification(between.getLowerBoundPattern());
    this.r = builder.getOrCreateSpecification(between.getUpperBoundPattern());
    this.s = builder.getOrCreateSpecification(response.getOtherPattern());
    this.queries.put(this.p.getFullyQualifiedName(), this.p);
    this.queries.put(this.q.getFullyQualifiedName(), this.q);
    this.queries.put(this.r.getFullyQualifiedName(), this.r);
    this.queries.put(this.s.getFullyQualifiedName(), this.s);
  }
  
  @Override
  protected String getStatementString() {
    final String pFqn = this.getFqn(this.p);
    final String qFqn = this.getFqn(this.q);
    final String rFqn = this.getFqn(this.r);
    final String sFqn = this.getFqn(this.s);
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("select * from ");
    String _name = this.getName();
    _builder.append(_name);
    _builder.newLineIfNotEmpty();
    _builder.append("match_recognize (");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("measures P as P, Q as Q, R as R, S as S");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("pattern (EoE | Q nPR* (P nRS* S nPR*)* (P nRS*)? (R | EoE))");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("define");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("P as P.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("Q as Q.");
    _builder.append(qFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("R as R.");
    _builder.append(rFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("S as S.");
    _builder.append(sFqn, "\t\t");
    _builder.append("? is not null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("nPR as nPR.");
    _builder.append(pFqn, "\t\t");
    _builder.append("? is null and nPR.");
    _builder.append(rFqn, "\t\t");
    _builder.append("? is null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("nRS as nRS.");
    _builder.append(rFqn, "\t\t");
    _builder.append("? is null and nRS.");
    _builder.append(sFqn, "\t\t");
    _builder.append("? is null,");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t");
    _builder.append("EoE as EoE.executionAboutToStop? is not null");
    _builder.newLine();
    _builder.append(")");
    _builder.newLine();
    final String result = _builder.toString();
    return result;
  }
  
  @Override
  protected TruthValue getStatus(final Map<String, List<Map<?, ?>>> events) {
    final List<Map<?, ?>> lP = events.get("P");
    int _xifexpression = (int) 0;
    if ((lP == null)) {
      _xifexpression = 0;
    } else {
      _xifexpression = lP.size();
    }
    final int nP = _xifexpression;
    final List<Map<?, ?>> lQ = events.get("Q");
    final boolean reachedQ = (!((lQ == null) || lQ.isEmpty()));
    final List<Map<?, ?>> lR = events.get("R");
    final boolean reachedR = (!((lR == null) || lR.isEmpty()));
    final List<Map<?, ?>> lS = events.get("S");
    int _xifexpression_1 = (int) 0;
    if ((lS == null)) {
      _xifexpression_1 = 0;
    } else {
      _xifexpression_1 = lS.size();
    }
    final int nS = _xifexpression_1;
    if (reachedQ) {
      if (reachedR) {
        if ((nP == nS)) {
          return TruthValue.UNKNOWN;
        } else {
          return TruthValue.VIOLATED;
        }
      } else {
        return TruthValue.SATISFIED;
      }
    } else {
      return TruthValue.SATISFIED;
    }
  }
}
