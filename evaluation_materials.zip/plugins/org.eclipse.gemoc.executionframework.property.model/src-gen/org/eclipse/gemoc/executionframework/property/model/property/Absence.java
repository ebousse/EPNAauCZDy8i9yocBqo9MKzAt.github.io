/**
 */
package org.eclipse.gemoc.executionframework.property.model.property;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Absence</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.executionframework.property.model.property.PropertyPackage#getAbsence()
 * @model
 * @generated
 */
public interface Absence extends TemporalProperty {
} // Absence
