/**
 */
package org.eclipse.gemoc.executionframework.property.model.property;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Scope</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.executionframework.property.model.property.PropertyPackage#getScope()
 * @model abstract="true"
 * @generated
 */
public interface Scope extends EObject {
} // Scope
