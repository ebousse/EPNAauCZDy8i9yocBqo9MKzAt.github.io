/**
 */
package org.eclipse.gemoc.executionframework.property.model.property;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Precedence</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.executionframework.property.model.property.PropertyPackage#getPrecedence()
 * @model
 * @generated
 */
public interface Precedence extends OrderedTemporalProperty {
} // Precedence
