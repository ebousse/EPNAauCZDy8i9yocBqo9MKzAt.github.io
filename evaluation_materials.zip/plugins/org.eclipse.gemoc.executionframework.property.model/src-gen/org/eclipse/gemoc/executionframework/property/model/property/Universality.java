/**
 */
package org.eclipse.gemoc.executionframework.property.model.property;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Universality</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.executionframework.property.model.property.PropertyPackage#getUniversality()
 * @model
 * @generated
 */
public interface Universality extends TemporalProperty {
} // Universality
