/**
 */
package org.eclipse.gemoc.executionframework.property.model.property;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>After Until</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.executionframework.property.model.property.PropertyPackage#getAfterUntil()
 * @model
 * @generated
 */
public interface AfterUntil extends LowerBounded, UpperBounded {
} // AfterUntil
