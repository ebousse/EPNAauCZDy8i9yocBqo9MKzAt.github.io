package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;

@SuppressWarnings("all")
public class OfferAspectOfferAspectProperties {
  public EList<Token> offeredTokens;
}
