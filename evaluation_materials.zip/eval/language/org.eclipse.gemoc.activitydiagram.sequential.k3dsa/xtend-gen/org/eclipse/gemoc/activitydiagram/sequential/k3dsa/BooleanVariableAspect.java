package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramFactory;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanValue;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspectBooleanVariableAspectProperties;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect;

@Aspect(className = BooleanVariable.class)
@OverrideAspectMethod
@SuppressWarnings("all")
public class BooleanVariableAspect extends VariableAspect {
  public static void execute(final BooleanVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspectBooleanVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspectBooleanVariableAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable)_self);
    };
  }
  
  @OverrideAspectMethod
  public static void init(final BooleanVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspectBooleanVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspectBooleanVariableAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void init()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect._privk3_init(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable)_self);
    };
  }
  
  @OverrideAspectMethod
  public static String print(final BooleanVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspectBooleanVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspectBooleanVariableAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# String print()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect._privk3_print(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable)_self);
    };
    return (java.lang.String)result;
  }
  
  protected static void _privk3_execute(final BooleanVariableAspectBooleanVariableAspectProperties _self_, final BooleanVariable _self) {
  }
  
  private static void super_init(final BooleanVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_init(_self_, _self);
  }
  
  protected static void _privk3_init(final BooleanVariableAspectBooleanVariableAspectProperties _self_, final BooleanVariable _self) {
    Value _currentValue = _self.getCurrentValue();
    boolean _tripleEquals = (_currentValue == null);
    if (_tripleEquals) {
      Value _initialValue = _self.getInitialValue();
      boolean _tripleNotEquals = (_initialValue != null);
      if (_tripleNotEquals) {
        _self.setCurrentValue(_self.getInitialValue());
      } else {
        final BooleanValue defaultValue = ActivitydiagramFactory.eINSTANCE.createBooleanValue();
        defaultValue.setValue(false);
        _self.setCurrentValue(defaultValue);
      }
    }
  }
  
  private static String super_print(final BooleanVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
    return  org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_print(_self_, _self);
  }
  
  protected static String _privk3_print(final BooleanVariableAspectBooleanVariableAspectProperties _self_, final BooleanVariable _self) {
    StringBuffer text = new StringBuffer();
    text.append(_self.getName());
    text.append(" = ");
    Value _currentValue = _self.getCurrentValue();
    text.append(((BooleanValue) _currentValue).isValue());
    return text.toString();
  }
}
