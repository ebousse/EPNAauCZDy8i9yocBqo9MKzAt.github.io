package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import java.util.Map;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Trace;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspectTraceAspectProperties;

@SuppressWarnings("all")
public class TraceAspectTraceAspectContext {
  public final static TraceAspectTraceAspectContext INSTANCE = new TraceAspectTraceAspectContext();
  
  public static TraceAspectTraceAspectProperties getSelf(final Trace _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspectTraceAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Trace, TraceAspectTraceAspectProperties> map = new java.util.WeakHashMap<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Trace, org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TraceAspectTraceAspectProperties>();
  
  public Map<Trace, TraceAspectTraceAspectProperties> getMap() {
    return map;
  }
}
