package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramFactory;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkNode;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkedToken;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspectForkNodeAspectProperties;

@Aspect(className = ForkNode.class)
@SuppressWarnings("all")
public class ForkNodeAspect extends ActivityNodeAspect {
  @OverrideAspectMethod
  public static void execute(final ForkNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspectForkNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspectForkNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkNode){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkNode)_self);
    };
  }
  
  private static void super_execute(final ForkNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final ForkNodeAspectForkNodeAspectProperties _self_, final ForkNode _self) {
    EList<Token> tokens = ActivityNodeAspect.takeOfferdTokens(_self);
    BasicEList<Token> forkedTokens = new BasicEList<Token>();
    for (final Token token : tokens) {
      {
        ForkedToken forkedToken = ActivitydiagramFactory.eINSTANCE.createForkedToken();
        forkedToken.setBaseToken(token);
        forkedToken.setRemainingOffersCount(_self.getOutgoing().size());
        forkedTokens.add(forkedToken);
      }
    }
    ActivityNodeAspect.addTokens(_self, forkedTokens);
    ActivityNodeAspect.sendOffers(_self, forkedTokens);
  }
}
