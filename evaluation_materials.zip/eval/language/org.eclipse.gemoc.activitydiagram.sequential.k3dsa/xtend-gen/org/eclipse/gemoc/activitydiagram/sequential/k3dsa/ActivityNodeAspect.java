package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Containment;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import fr.inria.diverse.k3.al.annotationprocessor.Step;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect;

@Aspect(className = ActivityNode.class)
@SuppressWarnings("all")
public class ActivityNodeAspect extends NamedElementAspect {
  @OverrideAspectMethod
  @Step
  public static void execute(final ActivityNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.OpaqueAction){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.OpaqueAction)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.JoinNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.JoinNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityFinalNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityFinalNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    		@Override
    		public void execute() {
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self);
    		}
    	};
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    	if (stepManager != null) {
    		stepManager.executeStep(_self, new Object[] {_self}, command, "ActivityNode", "execute");
    	} else {
    		command.execute();
    	}
    	;
    };
  }
  
  @Step
  public static void terminate(final ActivityNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void terminate()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    		@Override
    		public void execute() {
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_terminate(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self);
    		}
    	};
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    	if (stepManager != null) {
    		stepManager.executeStep(_self, new Object[] {_self}, command, "ActivityNode", "terminate");
    	} else {
    		command.execute();
    	}
    	;
    };
  }
  
  public static boolean isReady(final ActivityNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# boolean isReady()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_isReady(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self);
    };
    return (boolean)result;
  }
  
  @Step
  public static void sendOffers(final ActivityNode _self, final EList<Token> tokens) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void sendOffers(EList<Token>) from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect.sendOffers((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode)_self,tokens);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#void sendOffers(EList<Token>) from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect
    // #DispatchPointCut_before# void sendOffers(EList<Token>)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    		@Override
    		public void execute() {
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_sendOffers(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self,tokens);
    		}
    	};
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    	if (stepManager != null) {
    		stepManager.executeStep(_self, new Object[] {tokens}, command, "ActivityNode", "sendOffers");
    	} else {
    		command.execute();
    	}
    	;
    };
  }
  
  @Step
  public static EList<Token> takeOfferdTokens(final ActivityNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# EList<Token> takeOfferdTokens()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    		@Override
    		public void execute() {
    			addToResult(org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_takeOfferdTokens(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self));
    		}
    	};
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    	if (stepManager != null) {
    		stepManager.executeStep(_self, new Object[] {_self}, command, "ActivityNode", "takeOfferdTokens");
    	} else {
    		command.execute();
    	}
    	result = command.getResult();
    	;
    };
    return (org.eclipse.emf.common.util.EList<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token>)result;
  }
  
  @Step
  public static void addTokens(final ActivityNode _self, final EList<Token> tokens) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void addTokens(EList<Token>)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    		@Override
    		public void execute() {
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_addTokens(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self,tokens);
    		}
    	};
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    	if (stepManager != null) {
    		stepManager.executeStep(_self, new Object[] {tokens}, command, "ActivityNode", "addTokens");
    	} else {
    		command.execute();
    	}
    	;
    };
  }
  
  public static boolean hasOffers(final ActivityNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    Object result = null;
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#boolean hasOffers() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode){
    			result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect.hasOffers((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#boolean hasOffers() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#boolean hasOffers() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode){
    			result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect.hasOffers((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect#boolean hasOffers() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect
    // #DispatchPointCut_before# boolean hasOffers()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_hasOffers(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self);
    };
    return (boolean)result;
  }
  
  @Step
  public static void removeToken1(final ActivityNode _self, final Token token) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void removeToken1(Token)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    		@Override
    		public void execute() {
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_removeToken1(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self,token);
    		}
    	};
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    	if (stepManager != null) {
    		stepManager.executeStep(_self, new Object[] {token}, command, "ActivityNode", "removeToken1");
    	} else {
    		command.execute();
    	}
    	;
    };
  }
  
  @Containment
  public static EList<Token> heldTokens(final ActivityNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# EList<Token> heldTokens()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_heldTokens(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self);
    };
    return (org.eclipse.emf.common.util.EList<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token>)result;
  }
  
  @Containment
  public static void heldTokens(final ActivityNode _self, final EList<Token> heldTokens) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void heldTokens(EList<Token>)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_heldTokens(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self,heldTokens);
    };
  }
  
  private static void super_execute(final ActivityNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspectNamedElementAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspectNamedElementAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self) {
  }
  
  protected static void _privk3_terminate(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self) {
    _self.setRunning(false);
  }
  
  protected static boolean _privk3_isReady(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self) {
    return _self.isRunning();
  }
  
  protected static void _privk3_sendOffers(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self, final EList<Token> tokens) {
    EList<ActivityEdge> _outgoing = _self.getOutgoing();
    for (final ActivityEdge edge : _outgoing) {
      ActivityEdgeAspect.sendOffer(edge, tokens);
    }
  }
  
  protected static EList<Token> _privk3_takeOfferdTokens(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self) {
    final BasicEList<Token> allTokens = new BasicEList<Token>();
    EList<ActivityEdge> _incoming = _self.getIncoming();
    for (final ActivityEdge edge : _incoming) {
      {
        final EList<Token> tokens = ActivityEdgeAspect.takeOfferedTokens(edge);
        for (final Token token : tokens) {
          _self.getHeldTokens().add(token);
        }
        allTokens.addAll(tokens);
      }
    }
    return allTokens;
  }
  
  protected static void _privk3_addTokens(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self, final EList<Token> tokens) {
    for (final Token token : tokens) {
      _self.getHeldTokens().add(token);
    }
  }
  
  protected static boolean _privk3_hasOffers(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self) {
    boolean hasOffer = true;
    EList<ActivityEdge> _incoming = _self.getIncoming();
    for (final ActivityEdge edge : _incoming) {
      boolean _hasOffer = ActivityEdgeAspect.hasOffer(edge);
      boolean _not = (!_hasOffer);
      if (_not) {
        hasOffer = false;
      }
    }
    return hasOffer;
  }
  
  protected static void _privk3_removeToken1(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self, final Token token) {
    _self.getHeldTokens().remove(token);
  }
  
  protected static EList<Token> _privk3_heldTokens(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getHeldTokens") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.EList) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.heldTokens;
  }
  
  protected static void _privk3_heldTokens(final ActivityNodeAspectActivityNodeAspectProperties _self_, final ActivityNode _self, final EList<Token> heldTokens) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setHeldTokens")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, heldTokens);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.heldTokens = heldTokens;
    }
  }
}
