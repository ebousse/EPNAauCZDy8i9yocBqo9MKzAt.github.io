package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ControlFlow;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspect;

@Aspect(className = ControlFlow.class)
@SuppressWarnings("all")
public class ControlFlowAspect extends ActivityEdgeAspect {
}
