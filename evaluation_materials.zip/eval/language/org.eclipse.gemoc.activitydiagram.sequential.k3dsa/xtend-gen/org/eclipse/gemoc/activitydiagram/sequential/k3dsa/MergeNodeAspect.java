package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityEdge;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityEdgeAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspectMergeNodeAspectProperties;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@Aspect(className = MergeNode.class)
@SuppressWarnings("all")
public class MergeNodeAspect extends ActivityNodeAspect {
  @OverrideAspectMethod
  public static void execute(final MergeNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspectMergeNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspectMergeNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode)_self);
    };
  }
  
  public static boolean hasOffers(final MergeNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspectMergeNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspectMergeNodeAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# boolean hasOffers()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect._privk3_hasOffers(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode)_self);
    };
    return (boolean)result;
  }
  
  private static void super_execute(final MergeNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final MergeNodeAspectMergeNodeAspectProperties _self_, final MergeNode _self) {
    ActivityNodeAspect.sendOffers(_self, ActivityNodeAspect.takeOfferdTokens(_self));
  }
  
  protected static boolean _privk3_hasOffers(final MergeNodeAspectMergeNodeAspectProperties _self_, final MergeNode _self) {
    final Function1<ActivityEdge, Boolean> _function = (ActivityEdge edge) -> {
      return Boolean.valueOf(ActivityEdgeAspect.hasOffer(edge));
    };
    return IterableExtensions.<ActivityEdge>exists(_self.getIncoming(), _function);
  }
}
