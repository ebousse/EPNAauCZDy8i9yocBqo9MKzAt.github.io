package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Containment;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectProperties;

@Aspect(className = InputValue.class)
@SuppressWarnings("all")
public class InputValueAspect {
  public static Variable variable(final InputValue _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# Variable variable()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspect._privk3_variable(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue)_self);
    };
    return (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable)result;
  }
  
  public static void variable(final InputValue _self, final Variable variable) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void variable(Variable)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspect._privk3_variable(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue)_self,variable);
    };
  }
  
  @Containment
  public static Value value(final InputValue _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# Value value()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspect._privk3_value(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue)_self);
    };
    return (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value)result;
  }
  
  @Containment
  public static void value(final InputValue _self, final Value value) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspectInputValueAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void value(Value)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputValueAspect._privk3_value(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue)_self,value);
    };
  }
  
  protected static Variable _privk3_variable(final InputValueAspectInputValueAspectProperties _self_, final InputValue _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getVariable") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.variable;
  }
  
  protected static void _privk3_variable(final InputValueAspectInputValueAspectProperties _self_, final InputValue _self, final Variable variable) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setVariable")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, variable);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.variable = variable;
    }
  }
  
  protected static Value _privk3_value(final InputValueAspectInputValueAspectProperties _self_, final InputValue _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getValue") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.value;
  }
  
  protected static void _privk3_value(final InputValueAspectInputValueAspectProperties _self_, final InputValue _self, final Value value) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setValue")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, value);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.value = value;
    }
  }
}
