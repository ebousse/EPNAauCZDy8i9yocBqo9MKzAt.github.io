package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Trace;

@SuppressWarnings("all")
public class ActivityAspectActivityAspectProperties {
  public Trace trace;
}
