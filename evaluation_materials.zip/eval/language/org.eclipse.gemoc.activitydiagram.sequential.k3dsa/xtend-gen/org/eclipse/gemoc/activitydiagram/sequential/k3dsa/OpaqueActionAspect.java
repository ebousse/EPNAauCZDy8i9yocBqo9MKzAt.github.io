package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import java.util.function.Consumer;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Expression;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.OpaqueAction;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspectOpaqueActionAspectProperties;

@Aspect(className = OpaqueAction.class)
@SuppressWarnings("all")
public class OpaqueActionAspect extends ActivityNodeAspect {
  @OverrideAspectMethod
  public static void execute(final OpaqueAction _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspectOpaqueActionAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspectOpaqueActionAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.OpaqueAction){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.OpaqueAction)_self);
    };
  }
  
  private static void super_execute(final OpaqueAction _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final OpaqueActionAspectOpaqueActionAspectProperties _self_, final OpaqueAction _self) {
    final Consumer<Expression> _function = (Expression e) -> {
      ExpressionAspect.execute(e);
    };
    _self.getExpressions().forEach(_function);
    ActivityNodeAspect.sendOffers(_self, ActivityNodeAspect.takeOfferdTokens(_self));
  }
}
