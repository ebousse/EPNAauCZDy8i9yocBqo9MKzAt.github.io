package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import java.util.Map;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Input;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspectInputAspectProperties;

@SuppressWarnings("all")
public class InputAspectInputAspectContext {
  public final static InputAspectInputAspectContext INSTANCE = new InputAspectInputAspectContext();
  
  public static InputAspectInputAspectProperties getSelf(final Input _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspectInputAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Input, InputAspectInputAspectProperties> map = new java.util.WeakHashMap<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Input, org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspectInputAspectProperties>();
  
  public Map<Input, InputAspectInputAspectProperties> getMap() {
    return map;
  }
}
