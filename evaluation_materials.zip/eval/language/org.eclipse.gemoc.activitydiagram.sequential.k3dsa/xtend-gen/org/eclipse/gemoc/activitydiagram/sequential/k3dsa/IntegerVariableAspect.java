package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramFactory;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerValue;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspectIntegerVariableAspectProperties;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect;

@Aspect(className = IntegerVariable.class)
@SuppressWarnings("all")
public class IntegerVariableAspect extends VariableAspect {
  @OverrideAspectMethod
  public static void execute(final IntegerVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspectIntegerVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspectIntegerVariableAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable)_self);
    };
  }
  
  @OverrideAspectMethod
  public static void init(final IntegerVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspectIntegerVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspectIntegerVariableAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void init()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect._privk3_init(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable)_self);
    };
  }
  
  @OverrideAspectMethod
  public static String print(final IntegerVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspectIntegerVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspectIntegerVariableAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# String print()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect._privk3_print(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable)_self);
    };
    return (java.lang.String)result;
  }
  
  private static void super_execute(final IntegerVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final IntegerVariableAspectIntegerVariableAspectProperties _self_, final IntegerVariable _self) {
  }
  
  private static void super_init(final IntegerVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_init(_self_, _self);
  }
  
  protected static void _privk3_init(final IntegerVariableAspectIntegerVariableAspectProperties _self_, final IntegerVariable _self) {
    Value _currentValue = _self.getCurrentValue();
    boolean _tripleEquals = (_currentValue == null);
    if (_tripleEquals) {
      Value _initialValue = _self.getInitialValue();
      boolean _tripleNotEquals = (_initialValue != null);
      if (_tripleNotEquals) {
        _self.setCurrentValue(_self.getInitialValue());
      } else {
        final IntegerValue defaultValue = ActivitydiagramFactory.eINSTANCE.createIntegerValue();
        defaultValue.setValue(0);
        _self.setCurrentValue(defaultValue);
      }
    }
  }
  
  private static String super_print(final IntegerVariable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
    return  org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_print(_self_, _self);
  }
  
  protected static String _privk3_print(final IntegerVariableAspectIntegerVariableAspectProperties _self_, final IntegerVariable _self) {
    StringBuffer text = new StringBuffer();
    text.append(_self.getName());
    text.append(" = ");
    Value _currentValue = _self.getCurrentValue();
    text.append(((IntegerValue) _currentValue).getValue());
    return text.toString();
  }
}
