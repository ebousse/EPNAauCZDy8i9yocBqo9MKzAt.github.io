package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Expression;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspectExpressionAspectProperties;

@Aspect(className = Expression.class)
@SuppressWarnings("all")
public class ExpressionAspect {
  public static void execute(final Expression _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspectExpressionAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspectExpressionAspectContext.getSelf(_self);
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerCalculationExpressionAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerCalculationExpression){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerCalculationExpressionAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerCalculationExpression)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerCalculationExpressionAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanBinaryExpressionAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanBinaryExpression){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanBinaryExpressionAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanBinaryExpression)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanBinaryExpressionAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanUnaryExpressionAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanUnaryExpression){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanUnaryExpressionAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanUnaryExpression)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanUnaryExpressionAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerComparisonExpressionAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerComparisonExpression){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerComparisonExpressionAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerComparisonExpression)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerComparisonExpressionAspect
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Expression){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Expression)_self);
    };
  }
  
  protected static void _privk3_execute(final ExpressionAspectExpressionAspectProperties _self_, final Expression _self) {
  }
}
