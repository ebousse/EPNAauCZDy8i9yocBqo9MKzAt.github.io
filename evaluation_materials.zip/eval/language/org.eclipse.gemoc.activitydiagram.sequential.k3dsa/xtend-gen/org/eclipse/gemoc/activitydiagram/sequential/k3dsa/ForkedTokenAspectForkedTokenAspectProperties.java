package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;

@SuppressWarnings("all")
public class ForkedTokenAspectForkedTokenAspectProperties {
  public Token baseToken;
  
  public int remainingOffersCount;
}
