package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkedToken;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.JoinNode;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspectJoinNodeAspectProperties;

@Aspect(className = JoinNode.class)
@SuppressWarnings("all")
public class JoinNodeAspect extends ActivityNodeAspect {
  @OverrideAspectMethod
  public static void execute(final JoinNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspectJoinNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspectJoinNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.JoinNode){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.JoinNode)_self);
    };
  }
  
  private static void super_execute(final JoinNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final JoinNodeAspectJoinNodeAspectProperties _self_, final JoinNode _self) {
    EList<Token> tokens = ActivityNodeAspect.takeOfferdTokens(_self);
    final Consumer<Token> _function = (Token t) -> {
      int _remainingOffersCount = ((ForkedToken) t).getRemainingOffersCount();
      boolean _greaterThan = (_remainingOffersCount > 1);
      if (_greaterThan) {
        int _remainingOffersCount_1 = ((ForkedToken) t).getRemainingOffersCount();
        int _minus = (_remainingOffersCount_1 - 1);
        ((ForkedToken) t).setRemainingOffersCount(_minus);
      } else {
        BasicEList<Token> list = new BasicEList<Token>();
        list.add(t);
        ActivityNodeAspect.sendOffers(_self, list);
      }
    };
    tokens.forEach(_function);
  }
}
