package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Step;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties;

@Aspect(className = Variable.class)
@SuppressWarnings("all")
public class VariableAspect {
  @Step
  public static void execute(final Variable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable){
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    		@Override
    		public void execute() {
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable)_self);
    		}
    	};
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    	if (stepManager != null) {
    		stepManager.executeStep(_self, new Object[] {_self}, command, "Variable", "execute");
    	} else {
    		command.execute();
    	}
    	;
    };
  }
  
  @Step
  public static void init(final Variable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#void init() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect.init((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#void init() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#void init() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect.init((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#void init() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect
    // #DispatchPointCut_before# void init()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable){
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand command = new fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepCommand() {
    		@Override
    		public void execute() {
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_init(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable)_self);
    		}
    	};
    	fr.inria.diverse.k3.al.annotationprocessor.stepmanager.IStepManager stepManager = fr.inria.diverse.k3.al.annotationprocessor.stepmanager.StepManagerRegistry.getInstance().findStepManager(_self);
    	if (stepManager != null) {
    		stepManager.executeStep(_self, new Object[] {_self}, command, "Variable", "init");
    	} else {
    		command.execute();
    	}
    	;
    };
  }
  
  public static String print(final Variable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
    Object result = null;
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#String print() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable){
    			result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect.print((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanVariable)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#String print() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanVariableAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#String print() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable){
    			result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect.print((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.IntegerVariable)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect#String print() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.IntegerVariableAspect
    // #DispatchPointCut_before# String print()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_print(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable)_self);
    };
    return (java.lang.String)result;
  }
  
  public static Value currentValue(final Variable _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# Value currentValue()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_currentValue(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable)_self);
    };
    return (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value)result;
  }
  
  public static void currentValue(final Variable _self, final Value currentValue) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspectVariableAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void currentValue(Value)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.VariableAspect._privk3_currentValue(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Variable)_self,currentValue);
    };
  }
  
  protected static void _privk3_execute(final VariableAspectVariableAspectProperties _self_, final Variable _self) {
  }
  
  protected static void _privk3_init(final VariableAspectVariableAspectProperties _self_, final Variable _self) {
  }
  
  protected static String _privk3_print(final VariableAspectVariableAspectProperties _self_, final Variable _self) {
    return null;
  }
  
  protected static Value _privk3_currentValue(final VariableAspectVariableAspectProperties _self_, final Variable _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getCurrentValue") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.currentValue;
  }
  
  protected static void _privk3_currentValue(final VariableAspectVariableAspectProperties _self_, final Variable _self, final Value currentValue) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setCurrentValue")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, currentValue);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.currentValue = currentValue;
    }
  }
}
