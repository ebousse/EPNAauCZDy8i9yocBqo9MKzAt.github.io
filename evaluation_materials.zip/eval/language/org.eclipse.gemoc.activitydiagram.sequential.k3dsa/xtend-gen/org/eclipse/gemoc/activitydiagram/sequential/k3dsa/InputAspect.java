package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Containment;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Input;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspectInputAspectProperties;

@Aspect(className = Input.class)
@SuppressWarnings("all")
public class InputAspect {
  @Containment
  public static EList<InputValue> inputValues(final Input _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspectInputAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspectInputAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# EList<InputValue> inputValues()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Input){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspect._privk3_inputValues(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Input)_self);
    };
    return (org.eclipse.emf.common.util.EList<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InputValue>)result;
  }
  
  @Containment
  public static void inputValues(final Input _self, final EList<InputValue> inputValues) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspectInputAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspectInputAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void inputValues(EList<InputValue>)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Input){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InputAspect._privk3_inputValues(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Input)_self,inputValues);
    };
  }
  
  protected static EList<InputValue> _privk3_inputValues(final InputAspectInputAspectProperties _self_, final Input _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getInputValues") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.EList) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.inputValues;
  }
  
  protected static void _privk3_inputValues(final InputAspectInputAspectProperties _self_, final Input _self, final EList<InputValue> inputValues) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setInputValues")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, inputValues);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.inputValues = inputValues;
    }
  }
}
