package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityFinalNode;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspectActivityFinalNodeAspectProperties;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect;

@Aspect(className = ActivityFinalNode.class)
@SuppressWarnings("all")
public class ActivityFinalNodeAspect extends ActivityNodeAspect {
  @OverrideAspectMethod
  public static void execute(final ActivityFinalNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspectActivityFinalNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspectActivityFinalNodeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityFinalNode){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityFinalNode)_self);
    };
  }
  
  private static void super_execute(final ActivityFinalNode _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspectActivityNodeAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final ActivityFinalNodeAspectActivityFinalNodeAspectProperties _self_, final ActivityFinalNode _self) {
    ActivityNodeAspect.sendOffers(_self, ActivityNodeAspect.takeOfferdTokens(_self));
  }
}
