package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.NamedElement;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspectNamedElementAspectProperties;

@Aspect(className = NamedElement.class)
@SuppressWarnings("all")
public class NamedElementAspect {
  public static void execute(final NamedElement _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspectNamedElementAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspectNamedElementAspectContext.getSelf(_self);
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Activity){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Activity)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ForkNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ForkNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.MergeNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.MergeNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.JoinNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.JoinNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.JoinNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.DecisionNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.DecisionNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityFinalNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityFinalNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityFinalNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.OpaqueAction){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.OpaqueAction)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OpaqueActionAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.InitialNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.InitialNodeAspect
    	// BeginInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect
    		if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode){
    			org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect.execute((org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivityNode)_self);
    		} else
    		// EndInjectInto org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect#void execute() from org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityNodeAspect
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.NamedElement){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.NamedElementAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.NamedElement)_self);
    };
  }
  
  protected static void _privk3_execute(final NamedElementAspectNamedElementAspectProperties _self_, final NamedElement _self) {
  }
}
