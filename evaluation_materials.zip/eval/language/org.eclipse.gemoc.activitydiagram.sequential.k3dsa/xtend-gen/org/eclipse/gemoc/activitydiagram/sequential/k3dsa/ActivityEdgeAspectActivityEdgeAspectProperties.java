package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer;

@SuppressWarnings("all")
public class ActivityEdgeAspectActivityEdgeAspectProperties {
  public EList<Offer> offers;
}
