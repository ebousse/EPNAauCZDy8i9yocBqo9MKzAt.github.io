package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectProperties;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.TokenAspect;

@Aspect(className = Offer.class)
@SuppressWarnings("all")
public class OfferAspect {
  public static boolean hasTokens(final Offer _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# boolean hasTokens()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspect._privk3_hasTokens(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer)_self);
    };
    return (boolean)result;
  }
  
  public static void removeWithdrawnTokens(final Offer _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void removeWithdrawnTokens()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspect._privk3_removeWithdrawnTokens(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer)_self);
    };
  }
  
  public static EList<Token> offeredTokens(final Offer _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# EList<Token> offeredTokens()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer){
    	result = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspect._privk3_offeredTokens(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer)_self);
    };
    return (org.eclipse.emf.common.util.EList<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Token>)result;
  }
  
  public static void offeredTokens(final Offer _self, final EList<Token> offeredTokens) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void offeredTokens(EList<Token>)
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspect._privk3_offeredTokens(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer)_self,offeredTokens);
    };
  }
  
  protected static boolean _privk3_hasTokens(final OfferAspectOfferAspectProperties _self_, final Offer _self) {
    OfferAspect.removeWithdrawnTokens(_self);
    int _size = _self.getOfferedTokens().size();
    return (_size > 0);
  }
  
  protected static void _privk3_removeWithdrawnTokens(final OfferAspectOfferAspectProperties _self_, final Offer _self) {
    final BasicEList<Token> tokensToBeRemoved = new BasicEList<Token>();
    final Consumer<Token> _function = (Token token) -> {
      boolean _isWithdrawn = TokenAspect.isWithdrawn(token);
      if (_isWithdrawn) {
        tokensToBeRemoved.add(token);
      }
    };
    _self.getOfferedTokens().forEach(_function);
    _self.getOfferedTokens().removeAll(tokensToBeRemoved);
  }
  
  protected static EList<Token> _privk3_offeredTokens(final OfferAspectOfferAspectProperties _self_, final Offer _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getOfferedTokens") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (org.eclipse.emf.common.util.EList) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.offeredTokens;
  }
  
  protected static void _privk3_offeredTokens(final OfferAspectOfferAspectProperties _self_, final Offer _self, final EList<Token> offeredTokens) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setOfferedTokens")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, offeredTokens);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.offeredTokens = offeredTokens;
    }
  }
}
