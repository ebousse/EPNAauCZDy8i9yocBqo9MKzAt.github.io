package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanUnaryExpression;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanUnaryOperator;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanValue;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanUnaryExpressionAspectBooleanUnaryExpressionAspectProperties;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect;

@Aspect(className = BooleanUnaryExpression.class)
@SuppressWarnings("all")
public class BooleanUnaryExpressionAspect extends ExpressionAspect {
  @OverrideAspectMethod
  public static void execute(final BooleanUnaryExpression _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanUnaryExpressionAspectBooleanUnaryExpressionAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanUnaryExpressionAspectBooleanUnaryExpressionAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void execute()
    if (_self instanceof org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanUnaryExpression){
    	org.eclipse.gemoc.activitydiagram.sequential.k3dsa.BooleanUnaryExpressionAspect._privk3_execute(_self_, (org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.BooleanUnaryExpression)_self);
    };
  }
  
  private static void super_execute(final BooleanUnaryExpression _self) {
    final org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspectExpressionAspectProperties _self_ = org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspectExpressionAspectContext.getSelf(_self);
     org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ExpressionAspect._privk3_execute(_self_, _self);
  }
  
  protected static void _privk3_execute(final BooleanUnaryExpressionAspectBooleanUnaryExpressionAspectProperties _self_, final BooleanUnaryExpression _self) {
    int _value = _self.getOperator().getValue();
    boolean _equals = (_value == BooleanUnaryOperator.NOT_VALUE);
    if (_equals) {
      Value _currentValue = _self.getAssignee().getCurrentValue();
      Value _currentValue_1 = _self.getOperand().getCurrentValue();
      boolean _isValue = ((BooleanValue) _currentValue_1).isValue();
      boolean _not = (!_isValue);
      ((BooleanValue) _currentValue).setValue(_not);
    }
  }
}
