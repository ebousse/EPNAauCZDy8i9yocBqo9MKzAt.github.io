package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import java.util.Map;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer;
import org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectProperties;

@SuppressWarnings("all")
public class OfferAspectOfferAspectContext {
  public final static OfferAspectOfferAspectContext INSTANCE = new OfferAspectOfferAspectContext();
  
  public static OfferAspectOfferAspectProperties getSelf(final Offer _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Offer, OfferAspectOfferAspectProperties> map = new java.util.WeakHashMap<org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Offer, org.eclipse.gemoc.activitydiagram.sequential.k3dsa.OfferAspectOfferAspectProperties>();
  
  public Map<Offer, OfferAspectOfferAspectProperties> getMap() {
    return map;
  }
}
