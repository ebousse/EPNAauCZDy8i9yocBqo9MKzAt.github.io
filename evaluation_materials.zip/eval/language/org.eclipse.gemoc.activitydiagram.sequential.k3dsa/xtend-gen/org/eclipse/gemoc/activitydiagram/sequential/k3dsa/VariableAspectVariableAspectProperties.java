package org.eclipse.gemoc.activitydiagram.sequential.k3dsa;

import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Value;

@SuppressWarnings("all")
public class VariableAspectVariableAspectProperties {
  public Value currentValue;
}
