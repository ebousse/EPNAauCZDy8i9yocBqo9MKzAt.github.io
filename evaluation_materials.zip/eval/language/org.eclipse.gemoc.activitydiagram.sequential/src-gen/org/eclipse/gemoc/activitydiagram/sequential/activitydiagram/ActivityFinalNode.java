/**
 */
package org.eclipse.gemoc.activitydiagram.sequential.activitydiagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Activity Final Node</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramPackage#getActivityFinalNode()
 * @model
 * @generated
 */
public interface ActivityFinalNode extends FinalNode {
} // ActivityFinalNode
