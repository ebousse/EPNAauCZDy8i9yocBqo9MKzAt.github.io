/**
 */
package org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Action;
import org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Action</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ActionImpl extends ExecutableNodeImpl implements Action {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ActivitydiagramPackage.Literals.ACTION;
	}

} //ActionImpl
