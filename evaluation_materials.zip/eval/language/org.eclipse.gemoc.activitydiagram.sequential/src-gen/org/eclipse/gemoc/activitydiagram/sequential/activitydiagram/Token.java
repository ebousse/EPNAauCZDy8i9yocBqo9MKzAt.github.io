/**
 */
package org.eclipse.gemoc.activitydiagram.sequential.activitydiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramPackage#getToken()
 * @model
 * @generated
 */
public interface Token extends EObject {
} // Token
