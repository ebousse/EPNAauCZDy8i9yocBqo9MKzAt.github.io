/**
 */
package org.eclipse.gemoc.activitydiagram.sequential.activitydiagram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Boolean Variable</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.ActivitydiagramPackage#getBooleanVariable()
 * @model
 * @generated
 */
public interface BooleanVariable extends Variable {
} // BooleanVariable
