package org.eclipse.gemoc.benchmark.cases;

import java.util.Set;
import org.eclipse.gemoc.benchmark.utils.AbstractEngineProvider;
import org.eclipse.gemoc.benchmark.utils.AbstractRunConfigurationProvider;
import org.eclipse.gemoc.executionframework.engine.core.AbstractExecutionEngine;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionContext;
import org.eclipse.gemoc.xdsmlframework.api.core.IRunConfiguration;
import org.eclipse.gemoc.xdsmlframework.api.engine_addon.IEngineAddon;
import org.eclipse.xtext.xbase.lib.Exceptions;

@SuppressWarnings("all")
public abstract class BenchmarkingCase<E extends AbstractExecutionEngine<C, R>, C extends IExecutionContext<R, ?, ?>, R extends IRunConfiguration> {
  protected final Set<IEngineAddon> addonsToLoad;
  
  protected abstract AbstractEngineProvider<E, C, R> getEngineHelper();
  
  protected abstract AbstractRunConfigurationProvider<R> getRunConfigurationHelper();
  
  public BenchmarkingCase(final Set<IEngineAddon> addonsToLoad) {
    this.addonsToLoad = addonsToLoad;
  }
  
  public long initialize() {
    try {
      long _xblockexpression = (long) 0;
      {
        this.getEngineHelper().removeStoppedEngines();
        final long t = System.nanoTime();
        this.getEngineHelper().prepareEngine(this.getRunConfigurationHelper().getLaunchConfiguration(), this.addonsToLoad);
        long _nanoTime = System.nanoTime();
        _xblockexpression = (_nanoTime - t);
      }
      return _xblockexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public void execute() {
    this.getEngineHelper().execute();
  }
}
