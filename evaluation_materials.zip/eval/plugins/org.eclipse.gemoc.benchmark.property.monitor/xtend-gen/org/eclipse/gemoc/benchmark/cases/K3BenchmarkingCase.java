package org.eclipse.gemoc.benchmark.cases;

import java.util.Set;
import org.eclipse.emf.common.util.URI;
import org.eclipse.gemoc.benchmark.cases.BenchmarkingCase;
import org.eclipse.gemoc.benchmark.languages.K3Language;
import org.eclipse.gemoc.benchmark.utils.AbstractEngineProvider;
import org.eclipse.gemoc.benchmark.utils.AbstractRunConfigurationProvider;
import org.eclipse.gemoc.benchmark.utils.K3EngineProvider;
import org.eclipse.gemoc.benchmark.utils.K3RunConfigurationProvider;
import org.eclipse.gemoc.execution.sequential.javaengine.K3RunConfiguration;
import org.eclipse.gemoc.execution.sequential.javaengine.PlainK3ExecutionEngine;
import org.eclipse.gemoc.execution.sequential.javaengine.SequentialModelExecutionContext;
import org.eclipse.gemoc.xdsmlframework.api.engine_addon.IEngineAddon;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;

@SuppressWarnings("all")
public class K3BenchmarkingCase extends BenchmarkingCase<PlainK3ExecutionEngine, SequentialModelExecutionContext<K3RunConfiguration>, K3RunConfiguration> {
  private final URI entryPointElementUri;
  
  private final String initializationArguments;
  
  private final K3Language language;
  
  private final Set<String> addonIds;
  
  private K3EngineProvider engineProvider;
  
  private K3RunConfigurationProvider runConfigurationProvider;
  
  public K3BenchmarkingCase(final URI entryPointElementUri, final String initializationArguments, final K3Language language, final Set<String> addonIds, final Set<IEngineAddon> addonsToLoad) {
    super(addonsToLoad);
    this.entryPointElementUri = entryPointElementUri;
    this.initializationArguments = initializationArguments;
    this.language = language;
    this.addonIds = addonIds;
  }
  
  public K3BenchmarkingCase(final URI entryPointElementUri, final String initializationArguments, final K3Language language, final Set<String> addonIds) {
    super(CollectionLiterals.<IEngineAddon>emptySet());
    this.initializationArguments = initializationArguments;
    this.entryPointElementUri = entryPointElementUri;
    this.language = language;
    this.addonIds = addonIds;
  }
  
  @Override
  protected AbstractEngineProvider<PlainK3ExecutionEngine, SequentialModelExecutionContext<K3RunConfiguration>, K3RunConfiguration> getEngineHelper() {
    if ((this.engineProvider == null)) {
      K3EngineProvider _k3EngineProvider = new K3EngineProvider();
      this.engineProvider = _k3EngineProvider;
    }
    return this.engineProvider;
  }
  
  @Override
  protected AbstractRunConfigurationProvider<K3RunConfiguration> getRunConfigurationHelper() {
    if ((this.runConfigurationProvider == null)) {
      K3RunConfigurationProvider _k3RunConfigurationProvider = new K3RunConfigurationProvider(this.entryPointElementUri, this.initializationArguments, this.language, this.addonIds);
      this.runConfigurationProvider = _k3RunConfigurationProvider;
    }
    return this.runConfigurationProvider;
  }
}
