package org.eclipse.gemoc.benchmark.utils;

import java.lang.reflect.Field;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class CSVLine {
  public String propertyType;
  
  public long m1p1;
  
  public long m10p1;
  
  public long m10p10;
  
  public long m100p1;
  
  public long m100p10;
  
  public long m100p100;
  
  private final static String separator = ";";
  
  private static Iterable<Field> getAllFields() {
    final Function1<Field, Boolean> _function = (Field f) -> {
      boolean _contentEquals = f.getName().contentEquals("separator");
      return Boolean.valueOf((!_contentEquals));
    };
    return IterableExtensions.<Field>filter(((Iterable<Field>)Conversions.doWrapArray(CSVLine.class.getDeclaredFields())), _function);
  }
  
  public static String getColumnNames() {
    final Function1<Field, String> _function = (Field f) -> {
      return f.getName();
    };
    final Iterable<String> allNames = IterableExtensions.<Field, String>map(CSVLine.getAllFields(), _function);
    return IterableExtensions.join(allNames, CSVLine.separator);
  }
  
  public String customToString() {
    final Function1<Field, Object> _function = (Field f) -> {
      try {
        return f.get(this);
      } catch (Throwable _e) {
        throw Exceptions.sneakyThrow(_e);
      }
    };
    return IterableExtensions.join(IterableExtensions.<Field, Object>map(CSVLine.getAllFields(), _function), CSVLine.separator);
  }
}
