package org.eclipse.gemoc.benchmark.utils;

import java.util.Set;
import java.util.function.Consumer;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunchConfigurationType;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.emf.common.util.URI;
import org.eclipse.gemoc.benchmark.languages.BenchmarkLanguage;
import org.eclipse.gemoc.dsl.debug.ide.launch.AbstractDSLLaunchConfigurationDelegate;
import org.eclipse.gemoc.xdsmlframework.api.core.IRunConfiguration;
import org.eclipse.gemoc.xdsmlframework.api.extensions.engine_addon.EngineAddonSpecificationExtension;
import org.eclipse.gemoc.xdsmlframework.api.extensions.engine_addon.EngineAddonSpecificationExtensionPoint;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public abstract class AbstractRunConfigurationProvider<R extends IRunConfiguration> {
  protected final ILaunchConfigurationWorkingCopy launchConfiguration;
  
  public AbstractRunConfigurationProvider(final String launchConfigurationType, final URI model, final BenchmarkLanguage language, final Set<String> addonsToLoad) {
    try {
      final ILaunchConfigurationType launchType = DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurationType(launchConfigurationType);
      this.launchConfiguration = launchType.newInstance(null, language.getName());
      this.launchConfiguration.setAttribute(IRunConfiguration.LAUNCH_SELECTED_LANGUAGE, language.getName());
      this.launchConfiguration.setAttribute(AbstractDSLLaunchConfigurationDelegate.RESOURCE_URI, model.toPlatformString(true));
      final Function1<EngineAddonSpecificationExtension, Boolean> _function = (EngineAddonSpecificationExtension it) -> {
        return Boolean.valueOf(addonsToLoad.contains(it.getId()));
      };
      final Consumer<EngineAddonSpecificationExtension> _function_1 = (EngineAddonSpecificationExtension it) -> {
        this.launchConfiguration.setAttribute(it.getId(), true);
      };
      IterableExtensions.<EngineAddonSpecificationExtension>filter(EngineAddonSpecificationExtensionPoint.getSpecifications(), _function).forEach(_function_1);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public abstract R getLaunchConfiguration();
}
