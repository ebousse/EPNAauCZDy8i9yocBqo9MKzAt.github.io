package org.eclipse.gemoc.benchmark.languages;

@SuppressWarnings("all")
public abstract class BenchmarkLanguage {
  private final String name;
  
  public BenchmarkLanguage(final String name) {
    this.name = name;
  }
  
  public String getName() {
    return this.name;
  }
}
