package org.eclipse.gemoc.benchmark.property.monitor;

import java.util.Collections;
import java.util.Map;
import org.eclipse.gemoc.benchmark.languages.K3Language;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Pair;

@SuppressWarnings("all")
public class LanguageData {
  public final static String modelFolderName = "models";
  
  public final static String propertyFolderName = "properties";
  
  public final static String outputFolderName = "output";
  
  public final static int NBMEASURES = 1;
  
  public final static String projectName = "benchmark-project";
  
  public final static K3Language ad = new K3Language(
    "org.eclipse.gemoc.activitydiagram.sequential.ActivityDiagram", 
    "public static void org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityAspect.main(org.eclipse.gemoc.activitydiagram.sequential.activitydiagram.Activity)", 
    "org.eclipse.gemoc.activitydiagram.sequential.k3dsa.ActivityAspect.initializeModel");
  
  public final static Map<String, K3Language> languages = Collections.<String, K3Language>unmodifiableMap(CollectionLiterals.<String, K3Language>newHashMap(Pair.<String, K3Language>of(LanguageData.ad.getName(), LanguageData.ad)));
}
