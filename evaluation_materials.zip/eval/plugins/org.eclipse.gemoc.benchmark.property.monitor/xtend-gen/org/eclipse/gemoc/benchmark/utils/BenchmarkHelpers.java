package org.eclipse.gemoc.benchmark.utils;

import com.google.common.base.Objects;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.transaction.RecordingCommand;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.emf.transaction.util.TransactionUtil;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.IteratorExtensions;

@SuppressWarnings("all")
public class BenchmarkHelpers {
  public static void copyFileInWS(final File file, final IFolder destination, final IProgressMonitor m) {
    try {
      final IFile fileInProject = destination.getFile(file.getName());
      boolean _exists = fileInProject.exists();
      boolean _not = (!_exists);
      if (_not) {
        FileInputStream _fileInputStream = new FileInputStream(file);
        fileInProject.create(_fileInputStream, true, m);
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static IFolder copyFolderInWS(final File folder, final IResource destination, final IProgressMonitor m) {
    try {
      IFolder _xifexpression = null;
      if ((destination instanceof IProject)) {
        _xifexpression = ((IProject)destination).getFolder(folder.getName());
      } else {
        IFolder _xifexpression_1 = null;
        if ((destination instanceof IFolder)) {
          _xifexpression_1 = ((IFolder)destination).getFolder(folder.getName());
        } else {
          _xifexpression_1 = null;
        }
        _xifexpression = _xifexpression_1;
      }
      final IFolder folderCopy = _xifexpression;
      boolean _exists = folderCopy.exists();
      boolean _not = (!_exists);
      if (_not) {
        folderCopy.create(true, true, m);
      }
      File[] _listFiles = folder.listFiles();
      for (final File f : _listFiles) {
        boolean _isFile = f.isFile();
        if (_isFile) {
          BenchmarkHelpers.copyFileInWS(f, folderCopy, m);
        } else {
          boolean _isDirectory = f.isDirectory();
          if (_isDirectory) {
            BenchmarkHelpers.copyFolderInWS(f, folderCopy, m);
          }
        }
      }
      return folderCopy;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static IFolder copySingleFileInWS(final File folder, final String filename, final IResource destination, final IProgressMonitor m) {
    try {
      IFolder _xifexpression = null;
      if ((destination instanceof IProject)) {
        _xifexpression = ((IProject)destination).getFolder(folder.getName());
      } else {
        IFolder _xifexpression_1 = null;
        if ((destination instanceof IFolder)) {
          _xifexpression_1 = ((IFolder)destination).getFolder(folder.getName());
        } else {
          _xifexpression_1 = null;
        }
        _xifexpression = _xifexpression_1;
      }
      final IFolder folderCopy = _xifexpression;
      boolean _exists = folderCopy.exists();
      boolean _not = (!_exists);
      if (_not) {
        folderCopy.create(true, true, m);
      }
      File[] _listFiles = folder.listFiles();
      for (final File f : _listFiles) {
        if ((f.isFile() && Objects.equal(f.getName(), filename))) {
          BenchmarkHelpers.copyFileInWS(f, folderCopy, m);
        } else {
          boolean _isDirectory = f.isDirectory();
          if (_isDirectory) {
            BenchmarkHelpers.copyFolderInWS(f, folderCopy, m);
          }
        }
      }
      return folderCopy;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public static PrintStream createEmptyPrintStream() {
    final OutputStream emptyOutStream = new OutputStream() {
      @Override
      public void write(final int b) throws IOException {
      }
    };
    final PrintStream emptyPrintStream = new PrintStream(emptyOutStream) {
      @Override
      public void flush() {
      }
      
      @Override
      public void close() {
      }
      
      @Override
      public void write(final int b) {
      }
      
      @Override
      public void write(final byte[] b) {
      }
      
      @Override
      public void write(final byte[] buf, final int off, final int len) {
      }
      
      @Override
      public void print(final boolean b) {
      }
      
      @Override
      public void print(final char c) {
      }
      
      @Override
      public void print(final int i) {
      }
      
      @Override
      public void print(final long l) {
      }
      
      @Override
      public void print(final float f) {
      }
      
      @Override
      public void print(final double d) {
      }
      
      @Override
      public void print(final char[] s) {
      }
      
      @Override
      public void print(final String s) {
      }
      
      @Override
      public void print(final Object obj) {
      }
      
      @Override
      public void println() {
      }
      
      @Override
      public void println(final boolean x) {
      }
      
      @Override
      public void println(final char x) {
      }
      
      @Override
      public void println(final int x) {
      }
      
      @Override
      public void println(final long x) {
      }
      
      @Override
      public void println(final float x) {
      }
      
      @Override
      public void println(final double x) {
      }
      
      @Override
      public void println(final char[] x) {
      }
      
      @Override
      public void println(final String x) {
      }
      
      @Override
      public void println(final Object x) {
      }
      
      @Override
      public PrintStream printf(final String format, final Object... args) {
        return this;
      }
      
      @Override
      public PrintStream printf(final Locale l, final String format, final Object... args) {
        return this;
      }
      
      @Override
      public PrintStream format(final String format, final Object... args) {
        return this;
      }
      
      @Override
      public PrintStream format(final Locale l, final String format, final Object... args) {
        return this;
      }
      
      @Override
      public PrintStream append(final CharSequence csq) {
        return this;
      }
      
      @Override
      public PrintStream append(final CharSequence csq, final int start, final int end) {
        return this;
      }
      
      @Override
      public PrintStream append(final char c) {
        return this;
      }
    };
    return emptyPrintStream;
  }
  
  public static void clearResourceSet(final ResourceSet rs) {
    final TransactionalEditingDomain ed = TransactionUtil.getEditingDomain(rs);
    final RecordingCommand command = new RecordingCommand(ed, "Clean resources") {
      @Override
      protected void doExecute() {
        Set<Notifier> _set = IteratorExtensions.<Notifier>toSet(rs.getAllContents());
        for (final Notifier c : _set) {
          c.eAdapters().clear();
        }
        EList<Resource> _resources = rs.getResources();
        for (final Resource r : _resources) {
          r.eAdapters().clear();
        }
        rs.eAdapters().clear();
      }
    };
    ed.getCommandStack().execute(command);
  }
  
  public static <T extends Object, U extends Object, V extends Collection<U>> Map<T, V> mergeMaps(final Map<T, V>... maps) {
    final HashMap<T, V> result = new HashMap<T, V>();
    for (final Map<T, V> m : maps) {
      Set<T> _keySet = m.keySet();
      for (final T k : _keySet) {
        boolean _containsKey = result.containsKey(k);
        if (_containsKey) {
          final Collection<U> value = result.get(k);
          final Collection<U> test = m.get(k);
          value.addAll(test);
        } else {
          final List<U> value_1 = new ArrayList<U>();
          value_1.addAll(m.get(k));
          result.put(k, ((V) value_1));
        }
      }
    }
    return result;
  }
}
