package org.eclipse.gemoc.benchmark.utils;

import java.util.Set;
import org.eclipse.emf.common.util.URI;
import org.eclipse.gemoc.benchmark.languages.K3Language;
import org.eclipse.gemoc.benchmark.utils.AbstractRunConfigurationProvider;
import org.eclipse.gemoc.execution.sequential.javaengine.K3RunConfiguration;
import org.eclipse.xtext.xbase.lib.Exceptions;

@SuppressWarnings("all")
public class K3RunConfigurationProvider extends AbstractRunConfigurationProvider<K3RunConfiguration> {
  public K3RunConfigurationProvider(final URI entryPointElement, final String initializationArguments, final K3Language language, final Set<String> addonIds) {
    super("org.eclipse.gemoc.execution.sequential.javaengine.ui.launcher", entryPointElement.trimFragment(), language, addonIds);
    this.launchConfiguration.setAttribute(K3RunConfiguration.LAUNCH_METHOD_ENTRY_POINT, language.getEntryPoint());
    this.launchConfiguration.setAttribute(K3RunConfiguration.LAUNCH_INITIALIZATION_METHOD, language.getInitializationMethod());
    this.launchConfiguration.setAttribute(K3RunConfiguration.LAUNCH_INITIALIZATION_ARGUMENTS, initializationArguments);
    this.launchConfiguration.setAttribute(K3RunConfiguration.LAUNCH_MODEL_ENTRY_POINT, "/");
  }
  
  @Override
  public K3RunConfiguration getLaunchConfiguration() {
    try {
      return new K3RunConfiguration(this.launchConfiguration);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
