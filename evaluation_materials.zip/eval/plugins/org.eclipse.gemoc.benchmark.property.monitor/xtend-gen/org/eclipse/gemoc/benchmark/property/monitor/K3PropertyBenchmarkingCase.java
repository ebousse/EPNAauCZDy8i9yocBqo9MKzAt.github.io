package org.eclipse.gemoc.benchmark.property.monitor;

import com.google.common.collect.Iterables;
import java.util.Collections;
import java.util.Set;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.URI;
import org.eclipse.gemoc.benchmark.cases.K3BenchmarkingCase;
import org.eclipse.gemoc.benchmark.languages.K3Language;
import org.eclipse.gemoc.executionframework.property.model.property.TemporalProperty;
import org.eclipse.gemoc.executionframework.property.monitor.manager.PropertyManager;
import org.eclipse.gemoc.xdsmlframework.api.engine_addon.IEngineAddon;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class K3PropertyBenchmarkingCase extends K3BenchmarkingCase {
  public K3PropertyBenchmarkingCase(final URI entryPointElementUri, final String initializationArguments, final K3Language language, final Set<TemporalProperty> properties) {
    super(entryPointElementUri, initializationArguments, language, Collections.<String>unmodifiableSet(CollectionLiterals.<String>newHashSet()), Collections.<IEngineAddon>unmodifiableSet(CollectionLiterals.<IEngineAddon>newHashSet(new PropertyManager())));
    if ((properties != null)) {
      final PropertyManager propertyManager = IterableExtensions.<PropertyManager>head(Iterables.<PropertyManager>filter(this.addonsToLoad, PropertyManager.class));
      final Consumer<TemporalProperty> _function = (TemporalProperty p) -> {
        if (propertyManager!=null) {
          propertyManager.addProperty(p);
        }
      };
      IterableExtensions.<TemporalProperty>filterNull(properties).forEach(_function);
    }
  }
}
