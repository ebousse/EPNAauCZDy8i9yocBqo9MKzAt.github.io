package org.eclipse.gemoc.benchmark.property.monitor;

import com.google.common.base.Objects;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.gemoc.benchmark.cases.BenchmarkingCase;
import org.eclipse.gemoc.benchmark.languages.K3Language;
import org.eclipse.gemoc.benchmark.property.monitor.K3PropertyBenchmarkingCase;
import org.eclipse.gemoc.benchmark.property.monitor.LanguageData;
import org.eclipse.gemoc.benchmark.utils.BenchmarkHelpers;
import org.eclipse.gemoc.benchmark.utils.CSVHelper;
import org.eclipse.gemoc.benchmark.utils.EclipseTestUtil;
import org.eclipse.gemoc.benchmark.utils.Util;
import org.eclipse.gemoc.executionframework.property.model.property.TemporalProperty;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function0;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.junit.After;
import org.junit.Test;

@SuppressWarnings("all")
public class BenchmarkSingleJVMTestSuite {
  public final static String monitoringCaseProperty = "monitoringCaseProperty";
  
  public final static String modelProperty = "modelProperty";
  
  public final static String initializationArgumentsProperty = "initializationArgumentsProperty";
  
  public final static String caseNumberProperty = "caseNumberProperty";
  
  public final static String paramProperty = "paramProperty";
  
  public final static String languageProperty = "languageProperty";
  
  public final static String temporalPropertyProperty = "temporalPropertyProperty";
  
  public final static String outputFolderProperty = "outputFolderProperty";
  
  public final static String tmpExecutionTimeFileProperty = "tmpExecutionTimeFileProperty";
  
  public final static String errorString = "!!!!ERROR";
  
  public void log(final String s) {
    InputOutput.<String>println(("### [single test case] " + s));
  }
  
  private BenchmarkingCase<?, ?, ?> benchmarkingCase;
  
  private void execute(final IProgressMonitor m) {
    try {
      this.log("Preparing engine");
      System.gc();
      Thread.sleep(3000);
      this.log("Running engine");
      this.benchmarkingCase.execute();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private final Map<String, FileOutputStream> streams = new HashMap<String, FileOutputStream>();
  
  private final Map<String, PrintWriter> writers = new HashMap<String, PrintWriter>();
  
  private void addCSV(final String filename, final String folder) {
    try {
      final File dir = new File(folder);
      dir.mkdirs();
      final File csv = new File(((folder + "/") + filename));
      csv.createNewFile();
      final FileOutputStream csvStream = new FileOutputStream(csv);
      final PrintWriter csvWriter = new PrintWriter(csvStream, true);
      this.streams.put(filename, csvStream);
      this.writers.put(filename, csvWriter);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private List<String> getResults(final File file) {
    try {
      final FileReader fileReader = new FileReader(file);
      final BufferedReader bufferedReader = new BufferedReader(fileReader);
      final List<String> lines = new ArrayList<String>();
      for (String l = new Function0<String>() {
        public String apply() {
          try {
            return bufferedReader.readLine();
          } catch (Throwable _e) {
            throw Exceptions.sneakyThrow(_e);
          }
        }
      }.apply(); (l != null); l = bufferedReader.readLine()) {
        lines.add(l);
      }
      fileReader.close();
      file.delete();
      return lines;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void test() {
    try {
      final PrintStream emptyPrintStream = BenchmarkHelpers.createEmptyPrintStream();
      System.setOut(emptyPrintStream);
      System.setErr(emptyPrintStream);
      final String modelName = System.getProperty(BenchmarkSingleJVMTestSuite.modelProperty);
      final String initializationArguments = System.getProperty(BenchmarkSingleJVMTestSuite.initializationArgumentsProperty);
      final String caseNumber = System.getProperty(BenchmarkSingleJVMTestSuite.caseNumberProperty);
      final String monitoringCase = System.getProperty(BenchmarkSingleJVMTestSuite.monitoringCaseProperty);
      final String languageName = System.getProperty(BenchmarkSingleJVMTestSuite.languageProperty);
      final String propertyName = System.getProperty(BenchmarkSingleJVMTestSuite.temporalPropertyProperty);
      final String outputFolder = System.getProperty(BenchmarkSingleJVMTestSuite.outputFolderProperty);
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("execution");
      _builder.append(modelName);
      _builder.append("_");
      _builder.append(propertyName);
      _builder.append("_");
      _builder.append(caseNumber);
      _builder.append(".csv");
      final String executionCSVFilename = _builder.toString();
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("initialize");
      _builder_1.append(modelName);
      _builder_1.append("_");
      _builder_1.append(propertyName);
      _builder_1.append("_");
      _builder_1.append(caseNumber);
      _builder_1.append(".csv");
      final String initializationCSVFilename = _builder_1.toString();
      System.setProperty(BenchmarkSingleJVMTestSuite.tmpExecutionTimeFileProperty, "");
      final CSVHelper csv = new CSVHelper();
      this.addCSV(executionCSVFilename, outputFolder);
      this.addCSV(initializationCSVFilename, outputFolder);
      Util.cleanWorkspace();
      final Job job = new Job("single test case") {
        @Override
        protected IStatus run(final IProgressMonitor m) {
          try {
            final IProject eclipseProject = ResourcesPlugin.getWorkspace().getRoot().getProject(LanguageData.projectName);
            boolean _exists = eclipseProject.exists();
            if (_exists) {
              eclipseProject.delete(true, m);
            }
            eclipseProject.create(m);
            eclipseProject.open(m);
            final File modelFolder = new File(LanguageData.modelFolderName);
            final IFolder modelFolderInWS = BenchmarkHelpers.copyFolderInWS(modelFolder, eclipseProject, m);
            final IFile modelFileInProject = modelFolderInWS.getFile(modelName);
            final URI modelURI = URI.createPlatformResourceURI(modelFileInProject.getFullPath().toString(), true);
            final File propertyFolder = new File(LanguageData.propertyFolderName);
            final IFolder propertyFolderInWS = BenchmarkHelpers.copyFolderInWS(propertyFolder, eclipseProject, m);
            final TemporalProperty property = BenchmarkSingleJVMTestSuite.loadProperty(propertyFolderInWS, propertyName);
            K3PropertyBenchmarkingCase _switchResult = null;
            if (monitoringCase != null) {
              switch (monitoringCase) {
                case "K3Language":
                  K3Language _get = LanguageData.languages.get(languageName);
                  _switchResult = new K3PropertyBenchmarkingCase(modelURI, initializationArguments, _get, Collections.<TemporalProperty>unmodifiableSet(CollectionLiterals.<TemporalProperty>newHashSet(property)));
                  break;
              }
            }
            BenchmarkSingleJVMTestSuite.this.benchmarkingCase = _switchResult;
            BenchmarkSingleJVMTestSuite.this.log("Warming up.");
            for (int i = 0; (i < 10); i++) {
              {
                BenchmarkSingleJVMTestSuite.this.benchmarkingCase.initialize();
                BenchmarkSingleJVMTestSuite.this.execute(m);
                Util.cleanup("org.eclipse.gemoc.activitydiagram.sequential.k3dsa");
              }
            }
            for (int i = 0; (i < 20); i++) {
              {
                BenchmarkSingleJVMTestSuite.this.log(("Starting measure " + Integer.valueOf(i)));
                final long initTime = BenchmarkSingleJVMTestSuite.this.benchmarkingCase.initialize();
                final File tmpExecutionTimeFile = File.createTempFile("benchmarkExecution", "benchmark");
                System.setProperty(BenchmarkSingleJVMTestSuite.tmpExecutionTimeFileProperty, tmpExecutionTimeFile.getAbsolutePath());
                BenchmarkSingleJVMTestSuite.this.execute(m);
                csv.totalExecutionTimes.add(Long.valueOf(Long.parseLong(IterableExtensions.<String>head(BenchmarkSingleJVMTestSuite.this.getResults(tmpExecutionTimeFile)))));
                csv.initializationTimes.add(Long.valueOf(initTime));
                Util.cleanup("org.eclipse.gemoc.activitydiagram.sequential.k3dsa");
              }
            }
            BenchmarkSingleJVMTestSuite.this.writers.get(executionCSVFilename).println(csv.exportExecutionTimes());
            BenchmarkSingleJVMTestSuite.this.writers.get(initializationCSVFilename).println(csv.exportInitializationTimes());
            return Status.OK_STATUS;
          } catch (final Throwable _t) {
            if (_t instanceof Throwable) {
              final Throwable t = (Throwable)_t;
              BenchmarkSingleJVMTestSuite.this.log("Exception caught.");
              t.printStackTrace();
              final StringWriter sw = new StringWriter();
              PrintWriter _printWriter = new PrintWriter(sw);
              t.printStackTrace(_printWriter);
              final Status status = new Status(Status.ERROR, "trace single time test", "An error occured in the test case", t);
              return status;
            } else {
              throw Exceptions.sneakyThrow(_t);
            }
          }
        }
      };
      job.schedule();
      EclipseTestUtil.waitForJobs();
      IStatus _result = job.getResult();
      boolean _notEquals = (!Objects.equal(_result, Status.OK_STATUS));
      if (_notEquals) {
        throw job.getResult().getException();
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @After
  public void closeCSV() {
    final Consumer<FileOutputStream> _function = (FileOutputStream v) -> {
      try {
        v.close();
      } catch (Throwable _e) {
        throw Exceptions.sneakyThrow(_e);
      }
    };
    this.streams.values().forEach(_function);
    final Consumer<PrintWriter> _function_1 = (PrintWriter v) -> {
      v.close();
    };
    this.writers.values().forEach(_function_1);
  }
  
  private final static ResourceSetImpl resourceSet = new ResourceSetImpl();
  
  public static TemporalProperty loadProperty(final IFolder propertyFolder, final String propertyName) {
    final IFile propertyFileInProject = propertyFolder.getFile(propertyName);
    Object _xifexpression = null;
    boolean _exists = propertyFileInProject.exists();
    if (_exists) {
      final URI propertyURI = URI.createPlatformResourceURI(propertyFileInProject.getFullPath().toString(), true);
      final Resource propertyResource = BenchmarkSingleJVMTestSuite.resourceSet.getResource(propertyURI, true);
      if ((propertyResource != null)) {
        if (((propertyResource.getErrors().size() == 0) && (!propertyResource.getContents().isEmpty()))) {
          final EObject topElement = propertyResource.getContents().get(0);
          if ((topElement instanceof TemporalProperty)) {
            return ((TemporalProperty) topElement);
          } else {
            String _string = propertyURI.toString();
            String _plus = ("[ERROR] Root element is not a property: " + _string);
            InputOutput.<String>println(_plus);
            return null;
          }
        } else {
          String _string_1 = propertyURI.toString();
          String _plus_1 = ("[ERROR] Resource is empty or contains errors: " + _string_1);
          InputOutput.<String>println(_plus_1);
          return null;
        }
      } else {
        String _string_2 = propertyURI.toString();
        String _plus_2 = ("[ERROR] Property resource not found: " + _string_2);
        InputOutput.<String>println(_plus_2);
        return null;
      }
    } else {
      _xifexpression = null;
    }
    return ((TemporalProperty)_xifexpression);
  }
}
