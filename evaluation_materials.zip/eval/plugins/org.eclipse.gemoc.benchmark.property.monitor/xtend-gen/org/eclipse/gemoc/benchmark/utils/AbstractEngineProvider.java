package org.eclipse.gemoc.benchmark.utils;

import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.transaction.util.TransactionUtil;
import org.eclipse.gemoc.executionframework.engine.Activator;
import org.eclipse.gemoc.executionframework.engine.commons.EngineContextException;
import org.eclipse.gemoc.executionframework.engine.core.AbstractExecutionEngine;
import org.eclipse.gemoc.xdsmlframework.api.core.EngineStatus;
import org.eclipse.gemoc.xdsmlframework.api.core.ExecutionMode;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionContext;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionEngine;
import org.eclipse.gemoc.xdsmlframework.api.core.IRunConfiguration;
import org.eclipse.gemoc.xdsmlframework.api.engine_addon.IEngineAddon;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.search.SearchMatch;
import org.eclipse.jdt.core.search.SearchRequestor;

@SuppressWarnings("all")
public abstract class AbstractEngineProvider<E extends AbstractExecutionEngine<C, R>, C extends IExecutionContext<R, ?, ?>, R extends IRunConfiguration> {
  public static class DefaultSearchRequestor extends SearchRequestor {
    public IType _binaryType;
    
    @Override
    public void acceptSearchMatch(final SearchMatch match) throws CoreException {
      Object _element = match.getElement();
      this._binaryType = ((IType) _element);
      System.out.println(match.getElement());
    }
  }
  
  private E executionEngine;
  
  private C executionContext;
  
  protected abstract C getExecutionContext(final R runConfiguration, final ExecutionMode executionMode);
  
  protected abstract E getExecutionEngine();
  
  public void prepareEngine(final R runConf, final Set<IEngineAddon> addonsToLoad) throws CoreException, EngineContextException {
    final ExecutionMode executionMode = ExecutionMode.Run;
    this.executionContext = this.getExecutionContext(runConf, executionMode);
    this.executionContext.initializeResourceModel();
    final Consumer<IEngineAddon> _function = (IEngineAddon it) -> {
      this.executionContext.getExecutionPlatform().addEngineAddon(it);
    };
    addonsToLoad.forEach(_function);
    this.executionEngine = this.getExecutionEngine();
    this.executionEngine.initialize(this.executionContext);
  }
  
  public void execute() {
    this.executionEngine.start();
    this.executionEngine.joinThread();
  }
  
  public Resource getModel() {
    return this.executionEngine.getExecutionContext().getResourceModel();
  }
  
  public void removeStoppedEngines() {
    Set<Map.Entry<String, IExecutionEngine<?>>> _entrySet = Activator.getDefault().gemocRunningEngineRegistry.getRunningEngines().entrySet();
    for (final Map.Entry<String, IExecutionEngine<?>> engineEntry : _entrySet) {
      EngineStatus.RunStatus _runningStatus = engineEntry.getValue().getRunningStatus();
      if (_runningStatus != null) {
        switch (_runningStatus) {
          case Stopped:
            Activator.getDefault().gemocRunningEngineRegistry.unregisterEngine(engineEntry.getKey());
            break;
          default:
            break;
        }
      } else {
      }
    }
  }
  
  public void clearCommandStackAndAdapters() {
    TransactionUtil.getEditingDomain(this.executionContext.getResourceModel()).getCommandStack().flush();
    this.executionContext.getResourceModel().eAdapters().clear();
    this.executionContext.getResourceModel().unload();
  }
}
