package org.eclipse.gemoc.benchmark.property.monitor;

import java.io.File;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import org.eclipse.gemoc.benchmark.languages.BenchmarkLanguage;
import org.eclipse.gemoc.benchmark.property.monitor.BenchmarkSingleJVMTestSuite;
import org.eclipse.gemoc.benchmark.property.monitor.PropertyBenchmarkingData;
import org.eclipse.gemoc.benchmark.utils.PDETestResultsCollector;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
@SuppressWarnings("all")
public class BenchmarkTimeTestSuite {
  @Parameterized.Parameters
  public static Collection<Object[]> data() {
    return PropertyBenchmarkingData.getPropertyBenchmarkingCases();
  }
  
  @Parameterized.Parameter
  public String monitoringCase;
  
  @Parameterized.Parameter(1)
  public BenchmarkLanguage language;
  
  @Parameterized.Parameter(2)
  public String modelName;
  
  @Parameterized.Parameter(3)
  public String initializationArguments;
  
  @Parameterized.Parameter(4)
  public String propertyName;
  
  @Rule
  public TemporaryFolder tmpFolderCreator = new TemporaryFolder();
  
  private String outputFolderPath;
  
  /**
   * Fill in the path to your Java home, gemoc launcher
   * (e.g. "/home/<username>/Downloads/gemoc-studio/plugins/org.eclipse.equinox.launcher_1.5.0.v20180512-1130.jar"),
   * path to the workspace containing the configuration for the test suite
   * (i.e. where you executed the BenchmarkSingleJVMTestSuite manually),
   * and the path where you want to write the output of the evaluation.
   */
  private final static int port = 7777;
  
  private final static String minMemory = "10g";
  
  private final static String maxMemory = "10g";
  
  private final static String javaHome;
  
  private final static String gemocPath;
  
  private final static String wsPath;
  
  private final static String outputPath;
  
  private final static Map<String, Map<String, Set<String>>> caseNumber = CollectionLiterals.<String, Map<String, Set<String>>>newHashMap();
  
  public static String prepareProperty(final String key, final String value) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("-D");
    _builder.append(key);
    _builder.append("=");
    _builder.append(value);
    return _builder.toString();
  }
  
  @Before
  public void prepareOutput() {
    String _name = this.language.getName();
    int _lastIndexOf = this.language.getName().lastIndexOf(".");
    int _plus = (_lastIndexOf + 1);
    final String languageSimpleName = _name.substring(_plus);
    final String modelSimpleName = this.modelName.substring(0, this.modelName.lastIndexOf("."));
    final File outputFolder = new File(((((BenchmarkTimeTestSuite.outputPath + "/") + languageSimpleName) + "_") + modelSimpleName));
    boolean _exists = outputFolder.exists();
    boolean _not = (!_exists);
    if (_not) {
      outputFolder.mkdir();
    }
    this.outputFolderPath = outputFolder.getAbsolutePath();
  }
  
  public void log(final String s) {
    InputOutput.<String>println(((((("### [" + this.modelName) + "_") + this.propertyName) + "] ") + s));
  }
  
  @Test
  public void test() {
    try {
      final Function<String, Map<String, Set<String>>> _function = (String it) -> {
        return CollectionLiterals.<String, Set<String>>newHashMap();
      };
      final Function<String, Set<String>> _function_1 = (String it) -> {
        return CollectionLiterals.<String>newHashSet(this.initializationArguments);
      };
      BenchmarkTimeTestSuite.caseNumber.computeIfAbsent(this.modelName, _function).computeIfAbsent(this.propertyName, _function_1).add(this.initializationArguments);
      int _size = BenchmarkTimeTestSuite.caseNumber.get(this.modelName).get(this.propertyName).size();
      final int nb = (_size - 1);
      this.log("Preparing tmp folder");
      final File tmpWs = this.tmpFolderCreator.getRoot();
      String _prepareProperty = BenchmarkTimeTestSuite.prepareProperty(BenchmarkSingleJVMTestSuite.modelProperty, this.modelName);
      String _prepareProperty_1 = BenchmarkTimeTestSuite.prepareProperty(BenchmarkSingleJVMTestSuite.initializationArgumentsProperty, this.initializationArguments);
      String _prepareProperty_2 = BenchmarkTimeTestSuite.prepareProperty(BenchmarkSingleJVMTestSuite.caseNumberProperty, ("" + Integer.valueOf(nb)));
      String _prepareProperty_3 = BenchmarkTimeTestSuite.prepareProperty(BenchmarkSingleJVMTestSuite.temporalPropertyProperty, this.propertyName);
      String _prepareProperty_4 = BenchmarkTimeTestSuite.prepareProperty(BenchmarkSingleJVMTestSuite.languageProperty, this.language.getName());
      String _prepareProperty_5 = BenchmarkTimeTestSuite.prepareProperty(BenchmarkSingleJVMTestSuite.monitoringCaseProperty, this.monitoringCase);
      String _prepareProperty_6 = BenchmarkTimeTestSuite.prepareProperty(BenchmarkSingleJVMTestSuite.outputFolderProperty, this.outputFolderPath);
      String _string = Integer.valueOf(BenchmarkTimeTestSuite.port).toString();
      String _name = BenchmarkSingleJVMTestSuite.class.getName();
      String _absolutePath = tmpWs.getAbsolutePath();
      final List<String> params = Collections.<String>unmodifiableList(CollectionLiterals.<String>newArrayList(BenchmarkTimeTestSuite.javaHome, (("-Xms" + BenchmarkTimeTestSuite.minMemory) + "m"), (("-Xmx" + BenchmarkTimeTestSuite.maxMemory) + "m"), "-Declipse.pde.launch=true", "-Declipse.p2.data.area=@config.dir/p2", "-Dfile.encoding=UTF-8", _prepareProperty, _prepareProperty_1, _prepareProperty_2, _prepareProperty_3, _prepareProperty_4, _prepareProperty_5, _prepareProperty_6, "-classpath", BenchmarkTimeTestSuite.gemocPath, "org.eclipse.equinox.launcher.Main", "-os", "linux", "-ws", "gtk", "-arch", "x86_64", "-nl", "fr_FR", "-consoleLog", "-version", "3", "-port", _string, "-testLoaderClass", "org.eclipse.jdt.internal.junit4.runner.JUnit4TestLoader", "-loaderpluginname", "org.eclipse.jdt.junit4.runtime", "-classNames", _name, "-application", "org.eclipse.pde.junit.runtime.uitestapplication", "-product org.eclipse.platform.ide", "-testApplication", "org.eclipse.ui.ide.workbench", "-data", _absolutePath, "-configuration", (BenchmarkTimeTestSuite.wsPath + "/.metadata/.plugins/org.eclipse.pde.core/pde-junit/"), "-dev", (BenchmarkTimeTestSuite.wsPath + "/.metadata/.plugins/org.eclipse.pde.core/pde-junit/dev.properties"), "-os", "linux", "-ws", "gtk", "-arch", "x86_64", "-nl", "fr_FR", "-consoleLog", "-testpluginname", "org.eclipse.gemoc.benchmark.property.monitor"));
      final PDETestResultsCollector collector = new PDETestResultsCollector("listening for measure");
      this.log("Start dummy junit listener");
      final Runnable junitListener = new Runnable() {
        @Override
        public void run() {
          try {
            collector.run(BenchmarkTimeTestSuite.port);
          } catch (Throwable _e) {
            throw Exceptions.sneakyThrow(_e);
          }
        }
      };
      final Thread junitListenerThread = new Thread(junitListener);
      junitListenerThread.start();
      this.log("Start test in dedicated JVM");
      final ProcessBuilder processBuilder = new ProcessBuilder(params);
      final Process process = processBuilder.start();
      process.waitFor();
      this.log("Kill dummy junit listener");
      junitListenerThread.stop();
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
