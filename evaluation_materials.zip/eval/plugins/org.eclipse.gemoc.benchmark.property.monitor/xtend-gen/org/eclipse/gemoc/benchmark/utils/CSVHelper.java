package org.eclipse.gemoc.benchmark.utils;

import java.util.ArrayList;
import java.util.List;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;

@SuppressWarnings("all")
public class CSVHelper {
  public List<Long> totalExecutionTimes = new ArrayList<Long>();
  
  public List<Long> initializationTimes = new ArrayList<Long>();
  
  public Long memoryFootprint = Long.valueOf(0L);
  
  public String exportExecutionTimes() {
    final Function1<Long, Double> _function = (Long t) -> {
      return Double.valueOf(((t).longValue() / 1000000.0));
    };
    return IterableExtensions.join(ListExtensions.<Long, Double>map(this.totalExecutionTimes, _function), "\n").replace(".", ",");
  }
  
  public String exportInitializationTimes() {
    final Function1<Long, Double> _function = (Long t) -> {
      return Double.valueOf(((t).longValue() / 1000000.0));
    };
    return IterableExtensions.join(ListExtensions.<Long, Double>map(this.initializationTimes, _function), "\n").replace(".", ",");
  }
  
  public Long exportMemoryFootprint() {
    return this.memoryFootprint;
  }
}
