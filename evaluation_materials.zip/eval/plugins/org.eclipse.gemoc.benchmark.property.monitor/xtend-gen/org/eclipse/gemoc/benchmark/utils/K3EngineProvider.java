package org.eclipse.gemoc.benchmark.utils;

import org.eclipse.gemoc.benchmark.utils.AbstractEngineProvider;
import org.eclipse.gemoc.execution.sequential.javaengine.K3RunConfiguration;
import org.eclipse.gemoc.execution.sequential.javaengine.PlainK3ExecutionEngine;
import org.eclipse.gemoc.execution.sequential.javaengine.SequentialModelExecutionContext;
import org.eclipse.gemoc.xdsmlframework.api.core.ExecutionMode;
import org.eclipse.xtext.xbase.lib.Exceptions;

@SuppressWarnings("all")
public class K3EngineProvider extends AbstractEngineProvider<PlainK3ExecutionEngine, SequentialModelExecutionContext<K3RunConfiguration>, K3RunConfiguration> {
  @Override
  protected SequentialModelExecutionContext<K3RunConfiguration> getExecutionContext(final K3RunConfiguration runConfiguration, final ExecutionMode executionMode) {
    try {
      return new SequentialModelExecutionContext<K3RunConfiguration>(runConfiguration, executionMode);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Override
  protected PlainK3ExecutionEngine getExecutionEngine() {
    return new PlainK3ExecutionEngine();
  }
}
