package org.eclipse.gemoc.benchmark.utils;

import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IntegerRange;

@SuppressWarnings("all")
public class BenchmarkAmplifier {
  public static void main(final String[] args) {
    InputOutput.<String>println(BenchmarkAmplifier.amplifyModel(1, 5000));
  }
  
  public static String amplifyModel(final int n, final int t) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("activity benchmark {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// constants");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("int inc = 1,");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("int maxLoop = ");
    _builder.append((t - 1), "\t");
    _builder.append(",");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("int mod = 10,");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("// variables");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("int counterVar = 0,");
    _builder.newLine();
    {
      if ((n > 1)) {
        {
          IntegerRange _upTo = new IntegerRange(0, (n - 1));
          for(final Integer i : _upTo) {
            _builder.append("\t");
            _builder.append("int alwaysVar_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int existsVar_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int absenceVar_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int precedenceVar1_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int precedenceVar2_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int precedenceVar3_");
            _builder.append(i, "\t");
            _builder.append(" = -");
            _builder.append((t - 9), "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int precedenceVar4_");
            _builder.append(i, "\t");
            _builder.append(" = -");
            _builder.append((t - 7), "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int responseVar1_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int responseVar2_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int afterVar_");
            _builder.append(i, "\t");
            _builder.append(" = -");
            _builder.append((t / 2), "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int beforeVar_");
            _builder.append(i, "\t");
            _builder.append(" = -");
            _builder.append((t - 5), "\t");
            _builder.append(",");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int betweenVar1_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int betweenVar2_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int afterUntilVar1_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("int afterUntilVar2_");
            _builder.append(i, "\t");
            _builder.append(" = 0,");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("bool doneVar = false,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("bool notDoneVar = true");
        _builder.newLine();
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("nodes {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("initial initialNode out(edge01),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("merge mergeNode in (edge01, edge13) out (edge02),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action counterAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("counterVar = counterVar + inc,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("doneVar = counterVar >= maxLoop,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("notDoneVar = !doneVar");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge02) out (edge03),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action alwaysAction comp {");
        _builder.newLine();
        {
          IntegerRange _upTo_1 = new IntegerRange(0, (n - 1));
          boolean _hasElements = false;
          for(final Integer i_1 : _upTo_1) {
            if (!_hasElements) {
              _hasElements = true;
            } else {
              _builder.appendImmediate(",", "\t\t\t");
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("alwaysVar_");
            _builder.append(i_1, "\t\t\t");
            _builder.append(" = counterVar % mod");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge03) out (edge04),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action existsAction comp {");
        _builder.newLine();
        {
          IntegerRange _upTo_2 = new IntegerRange(0, (n - 1));
          boolean _hasElements_1 = false;
          for(final Integer i_2 : _upTo_2) {
            if (!_hasElements_1) {
              _hasElements_1 = true;
            } else {
              _builder.appendImmediate(",", "\t\t\t");
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("existsVar_");
            _builder.append(i_2, "\t\t\t");
            _builder.append(" = counterVar % mod");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge04) out (edge05),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action absenceAction comp {");
        _builder.newLine();
        {
          IntegerRange _upTo_3 = new IntegerRange(0, (n - 1));
          boolean _hasElements_2 = false;
          for(final Integer i_3 : _upTo_3) {
            if (!_hasElements_2) {
              _hasElements_2 = true;
            } else {
              _builder.appendImmediate(",", "\t\t\t");
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("absenceVar_");
            _builder.append(i_3, "\t\t\t");
            _builder.append(" = counterVar % mod");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge05) out (edge06),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action precedenceAction comp {");
        _builder.newLine();
        {
          IntegerRange _upTo_4 = new IntegerRange(0, (n - 1));
          boolean _hasElements_3 = false;
          for(final Integer i_4 : _upTo_4) {
            if (!_hasElements_3) {
              _hasElements_3 = true;
            } else {
              _builder.appendImmediate(",", "\t\t\t");
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("precedenceVar1_");
            _builder.append(i_4, "\t\t\t");
            _builder.append(" = counterVar % mod,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("precedenceVar2_");
            _builder.append(i_4, "\t\t\t");
            _builder.append(" = counterVar % mod,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("precedenceVar3_");
            _builder.append(i_4, "\t\t\t");
            _builder.append(" = precedenceVar3_");
            _builder.append(i_4, "\t\t\t");
            _builder.append(" + inc,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("precedenceVar4_");
            _builder.append(i_4, "\t\t\t");
            _builder.append(" = precedenceVar4_");
            _builder.append(i_4, "\t\t\t");
            _builder.append(" + inc");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge06) out (edge07),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action responseAction comp {");
        _builder.newLine();
        {
          IntegerRange _upTo_5 = new IntegerRange(0, (n - 1));
          boolean _hasElements_4 = false;
          for(final Integer i_5 : _upTo_5) {
            if (!_hasElements_4) {
              _hasElements_4 = true;
            } else {
              _builder.appendImmediate(",", "\t\t\t");
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("responseVar1_");
            _builder.append(i_5, "\t\t\t");
            _builder.append(" = counterVar % mod,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("responseVar2_");
            _builder.append(i_5, "\t\t\t");
            _builder.append(" = counterVar % mod");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge07) out (edge08),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action afterAction comp {");
        _builder.newLine();
        {
          IntegerRange _upTo_6 = new IntegerRange(0, (n - 1));
          boolean _hasElements_5 = false;
          for(final Integer i_6 : _upTo_6) {
            if (!_hasElements_5) {
              _hasElements_5 = true;
            } else {
              _builder.appendImmediate(",", "\t\t\t");
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("afterVar_");
            _builder.append(i_6, "\t\t\t");
            _builder.append(" = afterVar_");
            _builder.append(i_6, "\t\t\t");
            _builder.append(" + inc");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge08) out (edge09),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action beforeAction comp {");
        _builder.newLine();
        {
          IntegerRange _upTo_7 = new IntegerRange(0, (n - 1));
          boolean _hasElements_6 = false;
          for(final Integer i_7 : _upTo_7) {
            if (!_hasElements_6) {
              _hasElements_6 = true;
            } else {
              _builder.appendImmediate(",", "\t\t\t");
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("beforeVar_");
            _builder.append(i_7, "\t\t\t");
            _builder.append(" = beforeVar_");
            _builder.append(i_7, "\t\t\t");
            _builder.append(" + inc");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge09) out (edge10),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action betweenAction comp {");
        _builder.newLine();
        {
          IntegerRange _upTo_8 = new IntegerRange(0, (n - 1));
          boolean _hasElements_7 = false;
          for(final Integer i_8 : _upTo_8) {
            if (!_hasElements_7) {
              _hasElements_7 = true;
            } else {
              _builder.appendImmediate(",", "\t\t\t");
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("betweenVar1_");
            _builder.append(i_8, "\t\t\t");
            _builder.append(" = counterVar % mod,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("betweenVar2_");
            _builder.append(i_8, "\t\t\t");
            _builder.append(" = counterVar % mod");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge10) out (edge11),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action afterUntilAction comp {");
        _builder.newLine();
        {
          IntegerRange _upTo_9 = new IntegerRange(0, (n - 1));
          boolean _hasElements_8 = false;
          for(final Integer i_9 : _upTo_9) {
            if (!_hasElements_8) {
              _hasElements_8 = true;
            } else {
              _builder.appendImmediate(",", "\t\t\t");
            }
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("afterUntilVar1_");
            _builder.append(i_9, "\t\t\t");
            _builder.append(" = counterVar % mod,");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t\t");
            _builder.append("afterUntilVar2_");
            _builder.append(i_9, "\t\t\t");
            _builder.append(" = counterVar % mod");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge11) out (edge12),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("decision decisionNode in(edge12) out(edge13, edge14),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("final finalNode in(edge14)");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      } else {
        _builder.append("\t");
        _builder.append("int alwaysVar = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int existsVar = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int absenceVar = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int precedenceVar1 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int precedenceVar2 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int precedenceVar3 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int precedenceVar4 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int responseVar1 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int responseVar2 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int afterVar = -50,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int beforeVar = -95,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int betweenVar1 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int betweenVar2 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int afterUntilVar1 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("int afterUntilVar2 = 0,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("bool doneVar = false,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("bool notDoneVar = true");
        _builder.newLine();
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("nodes {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("initial initialNode out(edge01),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("merge mergeNode in (edge01, edge13) out (edge02),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action counterAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("counterVar = counterVar + inc,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("doneVar = counterVar >= maxLoop,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("notDoneVar = !doneVar");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge02) out (edge03),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action alwaysAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("alwaysVar = counterVar % mod");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge03) out (edge04),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action existsAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("existsVar = counterVar % mod");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge04) out (edge05),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action absenceAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("absenceVar = counterVar % mod");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge05) out (edge06),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action precedenceAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("precedenceVar1 = counterVar % mod,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("precedenceVar2 = counterVar % mod,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("precedenceVar3 = counterVar % mod,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("precedenceVar4 = counterVar % mod");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge06) out (edge07),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action responseAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("responseVar1 = counterVar % mod,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("responseVar2 = counterVar % mod");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge07) out (edge08),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action afterAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("afterVar = afterVar + inc");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge08) out (edge09),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action beforeAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("beforeVar = beforeVar + inc");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge09) out (edge10),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action betweenAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("betweenVar1 = counterVar % mod,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("betweenVar2 = counterVar % mod");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge10) out (edge11),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("action afterUntilAction comp {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("afterUntilVar1 = counterVar % mod,");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t\t");
        _builder.append("afterUntilVar2 = counterVar % mod");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("} in (edge11) out (edge12),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("decision decisionNode in(edge12) out(edge13, edge14),");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("final finalNode in(edge14)");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("edges {");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge01 from initialNode to mergeNode,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge02 from mergeNode to counterAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge03 from counterAction to alwaysAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge04 from alwaysAction to existsAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge05 from existsAction to absenceAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge06 from absenceAction to precedenceAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge07 from precedenceAction to responseAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge08 from responseAction to afterAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge09 from afterAction to beforeAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge10 from beforeAction to betweenAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge11 from betweenAction to afterUntilAction,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge12 from afterUntilAction to decisionNode,");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge13 from decisionNode to mergeNode [notDoneVar],");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("flow edge14 from decisionNode to finalNode [doneVar]");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }
  
  public static String amplifyScopeQueries(final int n) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ad.queries");
    {
      if ((n > 1)) {
        _builder.append(".x");
        _builder.append(n);
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("import \"http://org.gemoc.activitydiagram.sequential.xactivitydiagram/activitydiagram/\" as ad");
    _builder.newLine();
    {
      if ((n > 1)) {
        _builder.append("import java ^java.lang.String");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    {
      if ((n > 1)) {
        _builder.append("pattern beforeScope() {");
        _builder.newLine();
        {
          IntegerRange _upTo = new IntegerRange(0, (n - 1));
          for(final Integer i : _upTo) {
            _builder.append("\t");
            _builder.append("find beforeScopeAux(_, _, \"beforeVar_");
            _builder.append(i, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern afterScope() {");
        _builder.newLine();
        {
          IntegerRange _upTo_1 = new IntegerRange(0, (n - 1));
          for(final Integer i_1 : _upTo_1) {
            _builder.append("\t");
            _builder.append("find afterScopeAux(_, _, \"afterVar_");
            _builder.append(i_1, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern between1Scope() {");
        _builder.newLine();
        {
          IntegerRange _upTo_2 = new IntegerRange(0, (n - 1));
          for(final Integer i_2 : _upTo_2) {
            _builder.append("\t");
            _builder.append("find between1ScopeAux(_, _, \"betweenVar1_");
            _builder.append(i_2, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern between2Scope() {");
        _builder.newLine();
        {
          IntegerRange _upTo_3 = new IntegerRange(0, (n - 1));
          for(final Integer i_3 : _upTo_3) {
            _builder.append("\t");
            _builder.append("find between2ScopeAux(_, _, \"betweenVar2_");
            _builder.append(i_3, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern afterUntil1Scope() {");
        _builder.newLine();
        {
          IntegerRange _upTo_4 = new IntegerRange(0, (n - 1));
          for(final Integer i_4 : _upTo_4) {
            _builder.append("\t");
            _builder.append("find afterUntil1ScopeAux(_, _, \"afterUntilVar1_");
            _builder.append(i_4, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern afterUntil2Scope() {");
        _builder.newLine();
        {
          IntegerRange _upTo_5 = new IntegerRange(0, (n - 1));
          for(final Integer i_5 : _upTo_5) {
            _builder.append("\t");
            _builder.append("find afterUntil2ScopeAux(_, _, \"afterUntilVar2_");
            _builder.append(i_5, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern beforeScopeAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern afterScopeAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern between1ScopeAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern between2ScopeAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 5);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern afterUntil1ScopeAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern afterUntil2ScopeAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 5);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
      } else {
        _builder.append("pattern beforeScope(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"beforeVar_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern afterScope(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"afterVar_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern between1Scope(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"betweenVar1_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern between2Scope(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"betweenVar2_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 5);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern afterUntil1Scope(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"afterUntilVar1_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern afterUntil2Scope(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"afterUntilVar2_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 5);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
      }
    }
    return _builder.toString();
  }
  
  public static String amplifyPatternQueries(final int n) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ad.queries");
    {
      if ((n > 1)) {
        _builder.append(".x");
        _builder.append(n);
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    _builder.append("import \"http://org.gemoc.activitydiagram.sequential.xactivitydiagram/activitydiagram/\" as ad");
    _builder.newLine();
    {
      if ((n > 1)) {
        _builder.append("import java ^java.lang.String");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    {
      if ((n > 1)) {
        _builder.append("pattern alwaysPattern() {");
        _builder.newLine();
        {
          IntegerRange _upTo = new IntegerRange(0, (n - 1));
          for(final Integer i : _upTo) {
            _builder.append("\t");
            _builder.append("find alwaysPatternAux(_, _, \"alwaysVar_");
            _builder.append(i, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern existsPattern() {");
        _builder.newLine();
        {
          IntegerRange _upTo_1 = new IntegerRange(0, (n - 1));
          for(final Integer i_1 : _upTo_1) {
            _builder.append("\t");
            _builder.append("find existsPatternAux(_, _, \"existsVar_");
            _builder.append(i_1, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern neverPattern() {");
        _builder.newLine();
        {
          IntegerRange _upTo_2 = new IntegerRange(0, (n - 1));
          for(final Integer i_2 : _upTo_2) {
            _builder.append("\t");
            _builder.append("find neverPatternAux(_, _, \"neverVar_");
            _builder.append(i_2, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence1Pattern() {");
        _builder.newLine();
        {
          IntegerRange _upTo_3 = new IntegerRange(0, (n - 1));
          for(final Integer i_3 : _upTo_3) {
            _builder.append("\t");
            _builder.append("find precedence1PatternAux(_, _, \"precedenceVar1_");
            _builder.append(i_3, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence2Pattern() {");
        _builder.newLine();
        {
          IntegerRange _upTo_4 = new IntegerRange(0, (n - 1));
          for(final Integer i_4 : _upTo_4) {
            _builder.append("\t");
            _builder.append("find precedence2PatternAux(_, _, \"precedenceVar2_");
            _builder.append(i_4, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern response1Pattern() {");
        _builder.newLine();
        {
          IntegerRange _upTo_5 = new IntegerRange(0, (n - 1));
          for(final Integer i_5 : _upTo_5) {
            _builder.append("\t");
            _builder.append("find response1PatternAux(_, _, \"responseVar1_");
            _builder.append(i_5, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern response2Pattern() {");
        _builder.newLine();
        {
          IntegerRange _upTo_6 = new IntegerRange(0, (n - 1));
          for(final Integer i_6 : _upTo_6) {
            _builder.append("\t");
            _builder.append("find response2PatternAux(_, _, \"responseVar2_");
            _builder.append(i_6, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence3Pattern() {");
        _builder.newLine();
        {
          IntegerRange _upTo_7 = new IntegerRange(0, (n - 1));
          for(final Integer i_7 : _upTo_7) {
            _builder.append("\t");
            _builder.append("find precedence3PatternAux(_, _, \"precedenceVar3_");
            _builder.append(i_7, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence4Pattern() {");
        _builder.newLine();
        {
          IntegerRange _upTo_8 = new IntegerRange(0, (n - 1));
          for(final Integer i_8 : _upTo_8) {
            _builder.append("\t");
            _builder.append("find precedence4PatternAux(_, _, \"precedenceVar4_");
            _builder.append(i_8, "\t");
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern alwaysPatternAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("neg IntegerValue.value(varValue, 10);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern existsPatternAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 3);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern neverPatternAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("neg IntegerValue.value(varValue, 10);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence1PatternAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 1);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence2PatternAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 4);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern response1PatternAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 1);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern response2PatternAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 4);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence3PatternAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence4PatternAux(alwaysVar: IntegerVariable, varValue : IntegerValue, varName : java String) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, varName);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
      } else {
        _builder.append("pattern alwaysPattern(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"alwaysVar_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("neg IntegerValue.value(varValue, 10);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern existsPattern(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"existsVar_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 3);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern neverPattern(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"neverVar_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("neg IntegerValue.value(varValue, 10);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence1Pattern(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"precedenceVar1_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 1);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence2Pattern(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"precedenceVar2_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 4);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern response1Pattern(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"responseVar1_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 1);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern response2Pattern(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"responseVar2_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 4);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence3Pattern(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"precedenceVar3_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
        _builder.newLine();
        _builder.append("pattern precedence4Pattern(alwaysVar: IntegerVariable, varValue : IntegerValue) {");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.name(alwaysVar, \"precedenceVar4_0\");");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerVariable.currentValue(alwaysVar, varValue);");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("IntegerValue.value(varValue, 0);");
        _builder.newLine();
        _builder.append("}");
        _builder.newLine();
      }
    }
    return _builder.toString();
  }
}
