package org.eclipse.gemoc.benchmark.languages;

import org.eclipse.gemoc.benchmark.languages.BenchmarkLanguage;

@SuppressWarnings("all")
public class K3Language extends BenchmarkLanguage {
  private final String entryPoint;
  
  private final String initializationMethod;
  
  public K3Language(final String name, final String entryPoint, final String initializationMethod) {
    super(name);
    this.entryPoint = entryPoint;
    this.initializationMethod = initializationMethod;
  }
  
  public String getEntryPoint() {
    return this.entryPoint;
  }
  
  public String getInitializationMethod() {
    return this.initializationMethod;
  }
}
