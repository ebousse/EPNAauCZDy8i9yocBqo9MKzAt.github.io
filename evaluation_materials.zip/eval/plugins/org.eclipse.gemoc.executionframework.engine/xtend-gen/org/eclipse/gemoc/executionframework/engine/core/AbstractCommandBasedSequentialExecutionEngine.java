/**
 * Copyright (c) 2016 Inria and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Inria - initial API and implementation
 */
package org.eclipse.gemoc.executionframework.engine.core;

import java.util.Arrays;
import java.util.Collections;
import org.eclipse.emf.transaction.RecordingCommand;
import org.eclipse.gemoc.executionframework.engine.core.AbstractSequentialExecutionEngine;
import org.eclipse.gemoc.xdsmlframework.api.core.IExecutionContext;
import org.eclipse.gemoc.xdsmlframework.api.core.IRunConfiguration;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Conversions;

@SuppressWarnings("all")
public abstract class AbstractCommandBasedSequentialExecutionEngine<C extends IExecutionContext<R, ?, ?>, R extends IRunConfiguration> extends AbstractSequentialExecutionEngine<C, R> {
  /**
   * Must be called in a callback from the executed code from the operational
   * semantics.
   * 
   * @param caller
   * @param operationName
   * @param operation
   */
  protected void executeOperation(final Object caller, final String className, final String operationName, final Runnable operation) {
    this.executeOperation(caller, ((Object[])Conversions.unwrapArray(Collections.<Object>unmodifiableSet(CollectionLiterals.<Object>newHashSet()), Object.class)), className, operationName, operation);
  }
  
  protected void executeOperation(final Object caller, final Object[] parameters, final String className, final String operationName, final Runnable operation) {
    final RecordingCommand rc = new RecordingCommand(this.editingDomain) {
      @Override
      public void doExecute() {
        operation.run();
      }
    };
    try {
      this.beforeExecutionStep(caller, className, operationName, rc, Arrays.<Object>asList(parameters));
      rc.execute();
      this.afterExecutionStep();
    } finally {
      rc.dispose();
    }
  }
}
